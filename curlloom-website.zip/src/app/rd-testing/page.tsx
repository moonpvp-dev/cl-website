import { Metadata } from 'next'
import Link from 'next/link'
import { Button } from '@/components/ui/button'

export const metadata: Metadata = {
  title: 'R&D & Testing | CurlLoom',
  description: 'Learn about our disciplined approach to formulation development, community feedback loops, and quality standards.',
  openGraph: {
    title: 'R&D & Testing | CurlLoom',
    description: 'Learn about our disciplined approach to formulation development, community feedback loops, and quality standards.',
  },
}

const processSteps = [
  {
    title: 'Concept Development',
    description: 'Every formula starts with a clear objective: what cosmetic benefit are we trying to achieve? We research ingredient options, study mechanism of action, and develop initial formulations based on sound cosmetic science principles.',
  },
  {
    title: 'Iterative Testing',
    description: 'Formulations go through multiple rounds of internal testing. We evaluate texture, application, performance across hair types, and stability over time. Each iteration refines the formula based on observed results.',
  },
  {
    title: 'Community Feedback Loop',
    description: 'Selected formulations reach our tester community. Real curlies use the products in their actual routines and provide structured feedback. This real-world input shapes final adjustments before any public release.',
  },
  {
    title: 'Stability Assessment',
    description: 'Products undergo stability testing to ensure performance over time. We evaluate how formulations hold up under various storage conditions and usage patterns before releasing them.',
  },
  {
    title: 'Documentation & Standards',
    description: 'Every formulation is documented with full INCI ingredient lists, manufacturing specifications, and quality standards. We maintain records that support consistency and transparency.',
  },
]

const principles = [
  {
    title: 'No Rush to Launch',
    description: 'We don\'t release products until they\'re ready. Community feedback informs our timeline—if a formula needs more work, it gets more work. Speed doesn\'t compromise quality.',
  },
  {
    title: 'Honest Communication',
    description: 'We share what we know and acknowledge what we don\'t. If a product works well for certain hair types but not others, we say so. Transparency builds trust.',
  },
  {
    title: 'Patch-Test Protocol',
    description: 'We recommend patch testing for every product, and we test our own formulations for skin compatibility during development. This is basic cosmetic safety practice.',
  },
  {
    title: 'Feedback Integration',
    description: 'Community feedback isn\'t a marketing afterthought—it\'s integral to our process. Tester comments directly influence formulation decisions and product improvements.',
  },
]

export default function RDTestingPage() {
  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-6">
              R&D & Testing
            </h1>
            <p className="text-lg text-muted-foreground">
              Disciplined formulation development. Real-world testing. Community-informed iteration. We build products the right way, not the fast way.
            </p>
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-12 lg:py-20 bg-card/30">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-12 text-center">
              Our Process
            </h2>
            
            <div className="relative">
              {/* Vertical line */}
              <div className="absolute left-6 top-0 bottom-0 w-px bg-border" />
              
              <div className="space-y-12">
                {processSteps.map((step, index) => (
                  <div key={index} className="relative flex gap-6 pl-16">
                    <div className="absolute left-0 w-12 h-12 rounded-full bg-primary flex items-center justify-center">
                      <span className="text-primary-foreground font-semibold">{index + 1}</span>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">{step.title}</h3>
                      <p className="text-muted-foreground leading-relaxed">{step.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Principles */}
      <section className="py-12 lg:py-20">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-12 text-center">
              Guiding Principles
            </h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              {principles.map((item, index) => (
                <div key={index} className="bg-card border border-border/60 rounded-xl p-6">
                  <h3 className="text-lg font-semibold mb-3">{item.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Testers CTA */}
      <section className="py-12 lg:py-20 bg-card/30">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-6">
              Be Part of the Process
            </h2>
            <p className="text-muted-foreground mb-8">
              Our tester community gets early access to new formulations and directly influences product development. Limited to 30 spots.
            </p>
            <Link href="/testers">
              <Button className="bg-primary hover:bg-primary/90">
                Join Tester Program
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
