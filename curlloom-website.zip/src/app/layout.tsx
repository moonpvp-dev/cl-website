import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "CurlLoom | Performance-Focused Curl Care",
  description: "Lightweight definition and controlled hold—curl care built through disciplined formulation and community insight.",
  keywords: ["lightweight curl cream", "low buildup curl care", "water based leave in", "humidity resistant curl definition", "athlete friendly hair care"],
  authors: [{ name: "Parker DeLuca" }],
  icons: {
    icon: "/favicon.png",
  },
  openGraph: {
    title: "CurlLoom | Performance-Focused Curl Care",
    description: "Lightweight definition and controlled hold—curl care built through disciplined formulation and community insight.",
    url: "https://curlloom.com",
    siteName: "CurlLoom",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "CurlLoom | Performance-Focused Curl Care",
    description: "Lightweight definition and controlled hold—curl care built through disciplined formulation and community insight.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground min-h-screen flex flex-col`}
      >
        <Header />
        <main className="flex-1">
          {children}
        </main>
        <Footer />
        <Toaster />
      </body>
    </html>
  );
}
