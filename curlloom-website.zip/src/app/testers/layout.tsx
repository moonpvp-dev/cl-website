import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Join Our Tester Program | CurlLoom',
  description: 'Become a CurlLoom tester and get early access to our products. Limited to 30 spots—sign up today.',
  openGraph: {
    title: 'Join Our Tester Program | CurlLoom',
    description: 'Become a CurlLoom tester and get early access to our products. Limited to 30 spots—sign up today.',
  },
}

export { default } from './page'
