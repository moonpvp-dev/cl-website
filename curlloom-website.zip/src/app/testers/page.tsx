'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

const benefits = [
  {
    title: 'Free Product Samples',
    description: 'Receive full-size samples of our Crafted Curl products at no cost.',
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7" />
      </svg>
    ),
  },
  {
    title: 'Shape Future Products',
    description: 'Your feedback directly influences formulation decisions.',
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
      </svg>
    ),
  },
  {
    title: 'Exclusive Community Access',
    description: 'Join a private community of curl enthusiasts.',
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
      </svg>
    ),
  },
  {
    title: 'Early Access to New Products',
    description: 'Be first in line for upcoming releases.',
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
      </svg>
    ),
  },
]

const hairPatterns = [
  { value: 'wavy-2a', label: '2A - Loose waves' },
  { value: 'wavy-2b', label: '2B - Defined waves' },
  { value: 'wavy-2c', label: '2C - Strong waves' },
  { value: 'curly-3a', label: '3A - Loose curls' },
  { value: 'curly-3b', label: '3B - Medium curls' },
  { value: 'curly-3c', label: '3C - Tight curls' },
  { value: 'coily-4a', label: '4A - Soft coils' },
  { value: 'coily-4b', label: '4B - Z-pattern coils' },
  { value: 'coily-4c', label: '4C - Tight coils' },
]

const porosityLevels = [
  { value: 'low', label: 'Low - Products sit on top, slow absorption' },
  { value: 'medium', label: 'Medium - Balanced absorption' },
  { value: 'high', label: 'High - Quick absorption, loses moisture fast' },
  { value: 'unsure', label: 'Not sure' },
]

export default function TestersPage() {
  const [formData, setFormData] = useState({
    email: '',
    name: '',
    hairPattern: '',
    porosity: '',
    currentRoutine: '',
    whyInterested: '',
    instagram: '',
  })
  const [status, setStatus] = useState<'idle' | 'loading' | 'success'>('idle')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setStatus('loading')
    
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))
    
    setStatus('success')
  }

  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-6">
              <span className="gradient-text">Tester Program</span>
            </h1>
            <p className="text-lg text-muted-foreground mb-8">
              Join our exclusive tester community and help shape the future of curl care. Get early access to products, provide real feedback, and influence what we build next.
            </p>
            
            {/* Limited Spots Banner */}
            <div className="inline-flex items-center gap-3 bg-primary/10 border border-primary/30 rounded-full px-6 py-3">
              <svg className="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span className="text-sm font-medium text-primary">
                Limited Availability: Only 30 Tester Spots Available
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-12 lg:py-20 bg-card/30">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-12 text-center">
              What You Get
            </h2>
            
            <div className="grid sm:grid-cols-2 gap-6">
              {benefits.map((item, index) => (
                <div key={index} className="bg-card border border-border/60 rounded-xl p-6 flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                    {item.icon}
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">{item.title}</h3>
                    <p className="text-sm text-muted-foreground">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Application Form */}
      <section className="py-12 lg:py-20">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-2xl mx-auto">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-6 text-center">
              Apply to Join
            </h2>
            <p className="text-muted-foreground text-center mb-10">
              Fill out the form below to apply for our tester program. We select testers based on hair type diversity to ensure comprehensive feedback.
            </p>

            {status === 'success' ? (
              <div className="bg-card border border-primary/30 rounded-xl p-8 text-center">
                <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-6">
                  <svg className="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">Application Received</h3>
                <p className="text-muted-foreground mb-6">
                  Thank you for applying! We&apos;ll review your application and contact you if selected for the tester program.
                </p>
                <p className="text-sm text-muted-foreground">
                  Limited to 30 spots. Not all applicants will be selected.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Email */}
                <div>
                  <label htmlFor="email" className="block text-sm font-medium mb-2">
                    Email <span className="text-primary">*</span>
                  </label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your@email.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                    className="bg-card border-border focus:border-primary focus:ring-primary/20"
                  />
                </div>

                {/* Name */}
                <div>
                  <label htmlFor="name" className="block text-sm font-medium mb-2">
                    Name <span className="text-primary">*</span>
                  </label>
                  <Input
                    id="name"
                    placeholder="Your name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                    className="bg-card border-border focus:border-primary focus:ring-primary/20"
                  />
                </div>

                {/* Hair Pattern */}
                <div>
                  <label htmlFor="hairPattern" className="block text-sm font-medium mb-2">
                    Hair Pattern <span className="text-primary">*</span>
                  </label>
                  <Select
                    value={formData.hairPattern}
                    onValueChange={(value) => setFormData({ ...formData, hairPattern: value })}
                  >
                    <SelectTrigger className="bg-card border-border focus:border-primary focus:ring-primary/20">
                      <SelectValue placeholder="Select your pattern" />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      {hairPatterns.map((pattern) => (
                        <SelectItem key={pattern.value} value={pattern.value}>
                          {pattern.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Porosity */}
                <div>
                  <label htmlFor="porosity" className="block text-sm font-medium mb-2">
                    Porosity <span className="text-primary">*</span>
                  </label>
                  <Select
                    value={formData.porosity}
                    onValueChange={(value) => setFormData({ ...formData, porosity: value })}
                  >
                    <SelectTrigger className="bg-card border-border focus:border-primary focus:ring-primary/20">
                      <SelectValue placeholder="Select your porosity" />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      {porosityLevels.map((level) => (
                        <SelectItem key={level.value} value={level.value}>
                          {level.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Current Routine */}
                <div>
                  <label htmlFor="currentRoutine" className="block text-sm font-medium mb-2">
                    Current Hair Routine <span className="text-primary">*</span>
                  </label>
                  <Textarea
                    id="currentRoutine"
                    placeholder="Briefly describe your current products and routine..."
                    rows={4}
                    value={formData.currentRoutine}
                    onChange={(e) => setFormData({ ...formData, currentRoutine: e.target.value })}
                    required
                    className="bg-card border-border focus:border-primary focus:ring-primary/20 resize-none"
                  />
                </div>

                {/* Why Interested */}
                <div>
                  <label htmlFor="whyInterested" className="block text-sm font-medium mb-2">
                    Why are you interested in testing CurlLoom products? <span className="text-primary">*</span>
                  </label>
                  <Textarea
                    id="whyInterested"
                    placeholder="Tell us about your hair goals and why you want to test our products..."
                    rows={4}
                    value={formData.whyInterested}
                    onChange={(e) => setFormData({ ...formData, whyInterested: e.target.value })}
                    required
                    className="bg-card border-border focus:border-primary focus:ring-primary/20 resize-none"
                  />
                </div>

                {/* Instagram */}
                <div>
                  <label htmlFor="instagram" className="block text-sm font-medium mb-2">
                    Instagram Handle <span className="text-muted-foreground text-xs">(optional)</span>
                  </label>
                  <Input
                    id="instagram"
                    placeholder="@yourhandle"
                    value={formData.instagram}
                    onChange={(e) => setFormData({ ...formData, instagram: e.target.value })}
                    className="bg-card border-border focus:border-primary focus:ring-primary/20"
                  />
                </div>

                {/* Disclaimer */}
                <div className="bg-secondary/50 border border-border/60 rounded-xl p-4">
                  <div className="flex items-start gap-3">
                    <svg className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <div className="text-left">
                      <p className="text-sm font-medium text-foreground mb-1">Limited to 30 Testers</p>
                      <p className="text-xs text-muted-foreground">
                        Due to the exclusive nature of this program and product availability, we can only accept 30 testers for this phase. Selection is based on hair type diversity to ensure comprehensive feedback across different curl patterns. Not all applicants will be selected.
                      </p>
                    </div>
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={status === 'loading'}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                  size="lg"
                >
                  {status === 'loading' ? 'Submitting...' : 'Submit Application'}
                </Button>

                <p className="text-xs text-muted-foreground text-center">
                  No spam. Selected testers will be contacted via email.
                </p>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-12 lg:py-20 bg-card/30">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold tracking-tight mb-8 text-center">
              Frequently Asked Questions
            </h2>
            
            <div className="space-y-4">
              <div className="bg-card border border-border/60 rounded-xl p-6">
                <h3 className="font-semibold mb-2">How are testers selected?</h3>
                <p className="text-sm text-muted-foreground">
                  We select testers based on hair type diversity to ensure feedback across different curl patterns, porosities, and densities.
                </p>
              </div>
              
              <div className="bg-card border border-border/60 rounded-xl p-6">
                <h3 className="font-semibold mb-2">Is there a cost to join?</h3>
                <p className="text-sm text-muted-foreground">
                  No. Testers receive product samples at no cost. Your contribution is your honest feedback.
                </p>
              </div>
              
              <div className="bg-card border border-border/60 rounded-xl p-6">
                <h3 className="font-semibold mb-2">When will I know if I&apos;m selected?</h3>
                <p className="text-sm text-muted-foreground">
                  We review applications on a rolling basis. Selected testers are contacted via email within 1-2 weeks.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-xl mx-auto text-center">
            <h2 className="text-2xl font-bold tracking-tight mb-4">
              Questions Before Applying?
            </h2>
            <p className="text-muted-foreground mb-8">
              Check out our FAQ or reach out through our contact page.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/faq">
                <Button variant="outline" className="border-border hover:bg-secondary">
                  View FAQ
                </Button>
              </Link>
              <Link href="/contact">
                <Button variant="outline" className="border-border hover:bg-secondary">
                  Contact Us
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
