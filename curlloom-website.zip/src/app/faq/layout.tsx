import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'FAQ | CurlLoom',
  description: 'Clear answers about our formulas, usage, and policies.',
  openGraph: {
    title: 'FAQ | CurlLoom',
    description: 'Clear answers about our formulas, usage, and policies.',
  },
}

export { default } from './page'
