'use client'

import { useState } from 'react'
import { ChevronDown } from 'lucide-react'

const sections = [
  {
    id: 'product',
    title: 'Product Questions',
    questions: [
      {
        q: 'Are CurlLoom products medical or drug-based?',
        a: 'No. CurlLoom products are cosmetic formulations intended for external use only. They are not drugs and are not intended to diagnose, treat, cure, or prevent disease.',
      },
      {
        q: 'Are your formulas lightweight?',
        a: 'Yes. CurlLoom products are intentionally designed to be lightweight, low-buildup, and suitable for active lifestyles.',
      },
      {
        q: 'Should I patch test?',
        a: 'Yes. Apply a small amount to the inner forearm and wait 24 hours before full application.',
      },
      {
        q: 'Do results vary?',
        a: 'Yes. Hair porosity, routine, climate, and individual sensitivity may influence results.',
      },
    ],
  },
  {
    id: 'shipping',
    title: 'Shipping & Orders',
    questions: [
      {
        q: 'How long does shipping take?',
        a: 'Orders process within 2–4 business days. Delivery timelines depend on carrier and location.',
      },
      {
        q: 'What if my package shows delivered but I don\'t have it?',
        a: 'Please contact the carrier first. If needed, email help@curlloom.co.',
      },
    ],
  },
  {
    id: 'returns',
    title: 'Returns & Damages',
    questions: [
      {
        q: 'What if my product arrives damaged?',
        a: 'Contact help@curlloom.co within 5 days and include photos of the product and packaging.',
      },
      {
        q: 'Can I return opened products?',
        a: 'No. Opened cosmetic products cannot be returned for hygiene reasons.',
      },
    ],
  },
  {
    id: 'ingredients',
    title: 'Ingredients & Safety',
    questions: [
      {
        q: 'Are your products compliant with U.S. cosmetic regulations?',
        a: 'Yes. CurlLoom operates under applicable U.S. cosmetic regulations.',
      },
      {
        q: 'What if I experience irritation?',
        a: 'Discontinue use immediately and contact help@curlloom.co.',
      },
    ],
  },
  {
    id: 'wholesale',
    title: 'Wholesale',
    questions: [
      {
        q: 'Do you offer wholesale partnerships?',
        a: 'Yes. Please contact help@curlloom.co for wholesale inquiries.',
      },
    ],
  },
]

export default function FAQPage() {
  const [openQuestions, setOpenQuestions] = useState<string[]>([])

  const toggleQuestion = (id: string) => {
    setOpenQuestions(prev =>
      prev.includes(id)
        ? prev.filter(q => q !== id)
        : [...prev, id]
    )
  }

  return (
    <div className="flex flex-col">
      {/* Header */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-6">
              Frequently Asked Questions
            </h1>
            <p className="text-lg text-muted-foreground mb-4">
              Clear answers about our formulas, usage, and policies.
            </p>
            <p className="text-sm text-muted-foreground">
              Transparent. Direct. No inflated claims.
            </p>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-12 lg:py-20">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto space-y-8">
            {sections.map((section) => (
              <div key={section.id}>
                <h2 className="text-xl font-semibold mb-4 text-primary">
                  {section.title}
                </h2>
                <div className="space-y-3">
                  {section.questions.map((item, index) => {
                    const questionId = `${section.id}-${index}`
                    return (
                      <div
                        key={questionId}
                        className="border border-border/60 rounded-xl overflow-hidden"
                      >
                        <button
                          onClick={() => toggleQuestion(questionId)}
                          className="w-full flex items-center justify-between p-5 text-left hover:bg-card/50 transition-colors"
                        >
                          <span className="font-medium pr-4">{item.q}</span>
                          <ChevronDown
                            className={`w-5 h-5 text-muted-foreground flex-shrink-0 transition-transform duration-200 ${
                              openQuestions.includes(questionId) ? 'rotate-180' : ''
                            }`}
                          />
                        </button>
                        {openQuestions.includes(questionId) && (
                          <div className="px-5 pb-5 text-muted-foreground">
                            {item.a}
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer CTA */}
      <section className="py-12 lg:py-16">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <p className="text-muted-foreground">
              Still have questions? Contact{' '}
              <a href="mailto:help@curlloom.co" className="text-primary hover:underline">
                help@curlloom.co
              </a>
            </p>
          </div>
        </div>
      </section>
    </div>
  )
}
