'use client'

import { useState } from 'react'
import { ChevronDown } from 'lucide-react'

const sections = [
  {
    id: 'processing',
    title: 'Order Processing',
    content: `
      <p class="mb-4">Orders are processed within 2–4 business days (excluding weekends and holidays).</p>
      <p class="mb-4">You will receive:</p>
      <ul class="list-disc list-inside mb-4 space-y-1">
        <li>An order confirmation email</li>
        <li>A shipping confirmation with tracking information</li>
      </ul>
      <p>During high-volume periods, processing times may extend slightly. We prioritize quality control and packaging integrity before shipment.</p>
    `,
  },
  {
    id: 'shipping',
    title: 'Shipping',
    content: `
      <p class="mb-4">Shipping times vary by carrier and destination. Estimated delivery windows are displayed at checkout.</p>
      <p class="mb-4">Once an order has been transferred to the shipping carrier, CurlLoom is not responsible for carrier delays.</p>
      <p class="mb-4">Please verify your shipping address before placing your order. CurlLoom is not responsible for delivery issues caused by incorrect address submission.</p>
      <p>If your tracking shows "Delivered" but you have not received the package, please contact the carrier first. If additional assistance is needed, contact <a href="mailto:help@curlloom.co" class="text-primary hover:underline">help@curlloom.co</a>.</p>
    `,
  },
  {
    id: 'damaged',
    title: 'Damaged or Defective Items',
    content: `
      <p class="mb-4">We take packaging integrity seriously.</p>
      <p class="mb-2">If your product arrives:</p>
      <ul class="list-disc list-inside mb-4 space-y-1">
        <li>Leaking</li>
        <li>Cracked</li>
        <li>Broken</li>
        <li>With visible container damage</li>
      </ul>
      <p class="mb-2">Email <a href="mailto:help@curlloom.co" class="text-primary hover:underline">help@curlloom.co</a> within 5 calendar days of delivery.</p>
      <p class="mb-2">Include:</p>
      <ul class="list-disc list-inside mb-4 space-y-1">
        <li>Order number</li>
        <li>Clear photos of the product</li>
        <li>Photos of the shipping box</li>
        <li>Description of the issue</li>
      </ul>
      <p class="mb-4">If approved, we will issue a replacement or refund at our discretion.</p>
      <p>Damage occurring after delivery (dropping, improper storage, extreme heat exposure) is not covered.</p>
    `,
  },
  {
    id: 'returns',
    title: 'Returns & Refunds',
    content: `
      <p class="mb-4">Due to hygiene and safety standards, opened cosmetic products cannot be returned.</p>
      <p class="mb-4">Return requests must be submitted within 14 calendar days of delivery.</p>
      <p class="mb-2">To qualify:</p>
      <ul class="list-disc list-inside mb-4 space-y-1">
        <li>Product must be unopened</li>
        <li>Product must be unused</li>
        <li>Original packaging must remain intact</li>
        <li>Proof of purchase required</li>
      </ul>
      <p class="mb-4">Shipping costs are non-refundable.</p>
      <p class="mb-6">CurlLoom reserves the right to deny returns that do not meet these criteria.</p>
      <p class="text-sm text-muted-foreground italic">We design our policies to protect product safety and maintain fairness for all customers.</p>
    `,
  },
  {
    id: 'disputes',
    title: 'Payment Disputes',
    content: `
      <p class="mb-4">Before initiating a chargeback with your bank, please contact <a href="mailto:help@curlloom.co" class="text-primary hover:underline">help@curlloom.co</a> so we can resolve the issue quickly.</p>
      <p>Unauthorized or abusive chargebacks may result in purchase restrictions.</p>
    `,
  },
]

export default function ShippingReturnsPage() {
  const [openSections, setOpenSections] = useState<string[]>(['processing'])

  const toggleSection = (id: string) => {
    setOpenSections(prev =>
      prev.includes(id)
        ? prev.filter(s => s !== id)
        : [...prev, id]
    )
  }

  return (
    <div className="flex flex-col">
      {/* Header */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-6">
              Shipping & Returns
            </h1>
            <p className="text-lg text-muted-foreground mb-4">
              Clear policies designed to protect product integrity and ensure a smooth experience.
            </p>
            <p className="text-sm text-muted-foreground">
              Fast processing. Transparent policies. No surprises.
            </p>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-12 lg:py-20">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto space-y-4">
            {sections.map((section) => (
              <div
                key={section.id}
                className="border border-border/60 rounded-xl overflow-hidden"
              >
                <button
                  onClick={() => toggleSection(section.id)}
                  className="w-full flex items-center justify-between p-6 text-left hover:bg-card/50 transition-colors"
                >
                  <span className="text-lg font-semibold">{section.title}</span>
                  <ChevronDown
                    className={`w-5 h-5 text-muted-foreground transition-transform duration-200 ${
                      openSections.includes(section.id) ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {openSections.includes(section.id) && (
                  <div className="px-6 pb-6 text-muted-foreground">
                    <div dangerouslySetInnerHTML={{ __html: section.content }} />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer CTA */}
      <section className="py-12 lg:py-16">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <p className="text-muted-foreground">
              Questions? Contact{' '}
              <a href="mailto:help@curlloom.co" className="text-primary hover:underline">
                help@curlloom.co
              </a>
            </p>
          </div>
        </div>
      </section>
    </div>
  )
}
