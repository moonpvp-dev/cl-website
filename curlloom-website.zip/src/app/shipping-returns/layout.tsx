import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Shipping & Returns | CurlLoom',
  description: 'Clear policies designed to protect product integrity and ensure a smooth experience.',
  openGraph: {
    title: 'Shipping & Returns | CurlLoom',
    description: 'Clear policies designed to protect product integrity and ensure a smooth experience.',
  },
}

export { default } from './page'
