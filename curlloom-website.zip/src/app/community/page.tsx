import { Metadata } from 'next'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { EmailCapture } from '@/components/email-capture'

export const metadata: Metadata = {
  title: 'Community | CurlLoom',
  description: 'Join the CurlLoom tester program for early access to new formulations and help shape the future of curl care.',
  openGraph: {
    title: 'Community | CurlLoom',
    description: 'Join the CurlLoom tester program for early access to new formulations and help shape the future of curl care.',
  },
}

const benefits = [
  {
    title: 'Early Access',
    description: 'Try new formulations before public release. Be the first to experience what we\'re building.',
  },
  {
    title: 'Direct Feedback',
    description: 'Your voice matters. Tester feedback directly influences product development and formulation decisions.',
  },
  {
    title: 'Community Connection',
    description: 'Connect with other curl enthusiasts who care about performance-focused, thoughtfully formulated products.',
  },
  {
    title: 'Exclusive Updates',
    description: 'Get behind-the-scenes looks at our development process and first news on launches.',
  },
]

const expectations = [
  {
    title: 'Honest Feedback',
    description: 'We need your genuine experience—what works, what doesn\'t, and everything in between.',
  },
  {
    title: 'Timely Responses',
    description: 'Testers commit to providing feedback within agreed timeframes to keep development moving.',
  },
  {
    title: 'Constructive Communication',
    description: 'We maintain a respectful, constructive community. Disagreement is fine; disrespect is not.',
  },
  {
    title: 'Confidentiality',
    description: 'Some formulations are works in progress. Testers agree not to share unreleased product details publicly.',
  },
]

export default function CommunityPage() {
  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-6">
              <span className="gradient-text">Community-First</span> Development
            </h1>
            <p className="text-lg text-muted-foreground">
              We don\'t guess what works—we ask. Our tester program puts products in the hands of real curlies before they launch. Their feedback shapes every iteration.
            </p>
          </div>
        </div>
      </section>

      {/* Current Opportunity */}
      <section className="py-12 lg:py-20 bg-card/30">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-4xl">
            <div className="bg-card border border-primary/30 rounded-xl p-8 glow-sm">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
                <div>
                  <span className="text-xs font-medium text-primary uppercase tracking-wider">Now Open</span>
                  <h2 className="text-xl font-semibold mt-2 mb-2">Crafted Curl Leave-In Conditioner</h2>
                  <p className="text-muted-foreground">
                    Tester spots available for our water-based, low-buildup leave-in conditioner.
                  </p>
                </div>
                <div className="flex-shrink-0">
                  <EmailCapture variant="tester" className="lg:w-80" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-12 lg:py-20">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-4xl">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-12">
              What Testers Get
            </h2>
            
            <div className="grid sm:grid-cols-2 gap-6">
              {benefits.map((item, index) => (
                <div key={index} className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <svg className="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">{item.title}</h3>
                    <p className="text-sm text-muted-foreground">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Expectations */}
      <section className="py-12 lg:py-20 bg-card/30">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-4xl">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-12">
              What We Ask
            </h2>
            
            <div className="grid sm:grid-cols-2 gap-6">
              {expectations.map((item, index) => (
                <div key={index} className="bg-card border border-border/60 rounded-xl p-6">
                  <h3 className="font-semibold mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-12 lg:py-20">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-12">
              How It Works
            </h2>
            
            <div className="space-y-8">
              <div className="flex gap-6">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-semibold">
                  1
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Apply to Join</h3>
                  <p className="text-muted-foreground">Submit your email and basic hair profile information. We select testers based on current product needs and hair type diversity.</p>
                </div>
              </div>
              
              <div className="flex gap-6">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-semibold">
                  2
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Receive Product</h3>
                  <p className="text-muted-foreground">If selected, you\'ll receive tester samples with usage instructions and a feedback timeline.</p>
                </div>
              </div>
              
              <div className="flex gap-6">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-semibold">
                  3
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Test & Report</h3>
                  <p className="text-muted-foreground">Use the product in your regular routine and provide structured feedback through our form or direct communication.</p>
                </div>
              </div>
              
              <div className="flex gap-6">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-semibold">
                  4
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Influence Development</h3>
                  <p className="text-muted-foreground">Your feedback becomes part of our formulation decisions. See your input reflected in final products.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Join CTA */}
      <section className="py-16 lg:py-24 bg-card/30">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-xl mx-auto text-center">
            <h2 className="text-2xl font-bold tracking-tight mb-4">
              Ready to Join?
            </h2>
            <p className="text-muted-foreground mb-8">
              Tester spots are limited. Sign up to be considered for early access to our products.
            </p>
            <EmailCapture variant="tester" className="max-w-md mx-auto" />
            <p className="text-xs text-muted-foreground mt-4">No spam. Early access only.</p>
          </div>
        </div>
      </section>
    </div>
  )
}
