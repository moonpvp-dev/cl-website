import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Privacy Policy | CurlLoom',
  description: 'Learn how CurlLoom collects, uses, and protects your personal information.',
  openGraph: {
    title: 'Privacy Policy | CurlLoom',
    description: 'Learn how CurlLoom collects, uses, and protects your personal information.',
  },
}

export { default } from './page'
