'use client'

import { useState } from 'react'
import { ChevronDown } from 'lucide-react'

const sections = [
  {
    id: 'introduction',
    title: '1. Introduction',
    content: `CurlLoom LLC ("Company," "we," "us," or "our") is a U.S.-based cosmetic brand that formulates and distributes topical hair care products intended for external use only.

This Privacy Policy explains how we collect, use, disclose, and safeguard personal information obtained through curlloom.co, online forms, ecommerce transactions, email communications, and marketing subscriptions.

This policy applies solely to website visitors and customers.`,
  },
  {
    id: 'information-collected',
    title: '2. Information We Collect',
    content: `A. Information You Provide Voluntarily

We may collect personal information when you make a purchase, join our email list, submit a contact form, request updates, or create an account (if enabled). Information may include:
• Full name
• Email address
• Phone number
• Billing and shipping address
• Order details
• Customer service communications

CurlLoom LLC does not intentionally collect sensitive medical information.

B. Automatically Collected Information

When you access our website, we may automatically collect:
• IP address, browser type, device type, and operating system
• Pages visited, time and date of access, and referring URLs

This data is collected through cookies and analytics technologies.`,
  },
  {
    id: 'how-we-use',
    title: '3. How We Use Information',
    content: `We use collected information to:
• Process and fulfill orders
• Provide customer service
• Send transactional emails (order confirmation, shipping updates)
• Improve website functionality
• Maintain internal business records
• Prevent fraud and unauthorized transactions
• Send marketing communications (if you opt in)

We do not sell personal data.`,
  },
  {
    id: 'legal-context',
    title: '4. Legal and Regulatory Context',
    content: `CurlLoom LLC operates as a cosmetic manufacturer under U.S. law, including the Federal Food, Drug, and Cosmetic Act, the Modernization of Cosmetics Regulation Act of 2022, and applicable Federal Trade Commission standards.

Personal information collected through the website is used for ecommerce and communication purposes, not for medical or pharmaceutical research.`,
  },
  {
    id: 'cookies',
    title: '5. Cookies and Analytics',
    content: `We may use cookies and similar technologies to maintain website performance, analyze traffic patterns, improve user experience, and remember user preferences.

You may disable cookies in your browser settings. Some site functionality may be limited if cookies are disabled.`,
  },
  {
    id: 'payment',
    title: '6. Payment Processing',
    content: `All payment transactions are processed through secure third-party providers. CurlLoom LLC does not store full credit card numbers on its servers. Payment processors maintain their own privacy and security policies.`,
  },
  {
    id: 'data-sharing',
    title: '7. Data Sharing',
    content: `We may share personal information with:
• Payment processors
• Shipping carriers
• Ecommerce hosting platforms
• Email service providers
• Analytics providers
• Legal authorities if required by law

All third-party vendors are required to implement reasonable security safeguards. We do not sell or rent personal data.`,
  },
  {
    id: 'data-retention',
    title: '8. Data Retention',
    content: `We retain personal information only as long as necessary to complete transactions, maintain financial and tax records, comply with regulatory obligations, and resolve disputes. Retention periods may vary depending on legal and operational requirements.`,
  },
  {
    id: 'data-security',
    title: '9. Data Security',
    content: `We implement reasonable administrative, technical, and physical safeguards, including SSL encryption, secure hosting environments, limited internal data access, and password-protected systems.

However, no online transmission method is guaranteed to be completely secure.`,
  },
  {
    id: 'privacy-rights',
    title: '10. Your Privacy Rights',
    content: `Depending on your state of residence (including rights under the Virginia Consumer Data Protection Act), you may have the right to:
• Request access to your personal data
• Request correction of inaccurate data
• Request deletion (subject to legal retention obligations)
• Opt out of marketing communications

To exercise these rights, contact help@curlloom.co. We may verify identity before processing certain requests.`,
  },
  {
    id: 'children',
    title: '11. Children\'s Privacy',
    content: `CurlLoom's website is not directed to children under 13 years of age. We do not knowingly collect personal information from children under 13. If we become aware that such information has been collected, we will delete it promptly.`,
  },
  {
    id: 'third-party',
    title: '12. Third-Party Links',
    content: `Our website may contain links to third-party websites. We are not responsible for the privacy practices of those websites.`,
  },
  {
    id: 'governing-law',
    title: '13. Governing Law',
    content: `This Privacy Policy shall be governed by and interpreted in accordance with the laws of the Commonwealth of Virginia.`,
  },
  {
    id: 'changes',
    title: '14. Changes to This Policy',
    content: `We may update this Privacy Policy from time to time. Updates will be reflected by revising the "Last Updated" date above. Continued use of the website constitutes acceptance of the revised policy.`,
  },
]

export default function PrivacyPage() {
  const [openSections, setOpenSections] = useState<string[]>([])

  const toggleSection = (id: string) => {
    setOpenSections(prev =>
      prev.includes(id)
        ? prev.filter(s => s !== id)
        : [...prev, id]
    )
  }

  return (
    <div className="flex flex-col">
      {/* Header */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-6">
              Privacy Policy
            </h1>
            <p className="text-muted-foreground mb-2">
              CurlLoom LLC
            </p>
            <p className="text-sm text-muted-foreground">
              Effective Date: February 2025 · Last Updated: February 2025
            </p>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-12 lg:py-20">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto space-y-3">
            {sections.map((section) => (
              <div
                key={section.id}
                className="border border-border/60 rounded-xl overflow-hidden"
              >
                <button
                  onClick={() => toggleSection(section.id)}
                  className="w-full flex items-center justify-between p-5 text-left hover:bg-card/50 transition-colors"
                >
                  <span className="font-medium pr-4">{section.title}</span>
                  <ChevronDown
                    className={`w-5 h-5 text-muted-foreground flex-shrink-0 transition-transform duration-200 ${
                      openSections.includes(section.id) ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {openSections.includes(section.id) && (
                  <div className="px-5 pb-5 text-muted-foreground whitespace-pre-line">
                    {section.content}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <section className="py-12 lg:py-16">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <p className="text-muted-foreground">
              Questions? Contact{' '}
              <a href="mailto:help@curlloom.co" className="text-primary hover:underline">
                help@curlloom.co
              </a>
            </p>
          </div>
        </div>
      </section>
    </div>
  )
}
