import { Metadata } from 'next'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { EmailCapture } from '@/components/email-capture'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'

export const metadata: Metadata = {
  title: 'Crafted Curl Leave-In Conditioner | CurlLoom',
  description: 'Lightweight hydration and definition for all curl patterns. Water-based, low-buildup formula designed for regular use.',
  openGraph: {
    title: 'Crafted Curl Leave-In Conditioner | CurlLoom',
    description: 'Lightweight hydration and definition for all curl patterns. Water-based, low-buildup formula designed for regular use.',
  },
}

const ingredients = [
  'Aqua (Water)',
  'Aloe Barbadensis Leaf Juice',
  'Propanediol',
  'Glycerin',
  'Cetearyl Olivate',
  'Sorbitan Olivate',
  'Helianthus Annuus (Sunflower) Seed Oil',
  'Vitis Vinifera (Grape) Seed Oil',
  'Beta-Glucan',
  'Althaea Officinalis Root Extract',
  'Sodium PCA',
  'Sodium Gluconate',
  'Tocopherol',
  'Benzyl Alcohol',
  'Salicylic Acid',
  'Glycerin',
  'Sorbic Acid',
]

const faqs = [
  {
    question: 'What makes this leave-in different from others?',
    answer: 'Our formula is water-dominant with controlled humectants, meaning it hydrates without the heavy residue common in many leave-ins. The film-forming polysaccharides provide definition that lasts without buildup over time.',
  },
  {
    question: 'Can I use this daily?',
    answer: 'Yes. The lightweight, low-buildup formula is designed for regular use. On non-wash days, you can refresh with water and a small amount of leave-in.',
  },
  {
    question: 'Will this work for my hair porosity?',
    answer: 'Our formula works across porosity levels. Low porosity hair benefits from the lightweight, easily-absorbed base. High porosity hair gets hydration retention from the film-forming ingredients. Adjust amount based on your hair\'s needs.',
  },
  {
    question: 'Can I layer this with other products?',
    answer: 'Absolutely. Our leave-in is designed as a foundational layer. Follow with curl cream for enhanced definition or gel for stronger hold. The formula plays well with most styling products.',
  },
  {
    question: 'How much should I use?',
    answer: 'Start with a quarter-sized amount for short hair, golf ball for medium length, and tennis ball for long hair. Adjust based on your hair\'s density and porosity. It\'s easier to add more than remove excess.',
  },
  {
    question: 'Is this suitable for color-treated hair?',
    answer: 'Yes. Our formula is gentle and free of harsh sulfates and drying alcohols that can strip color. As with any product, patch test first if you have concerns.',
  },
]

export default function LeaveInConditionerPage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="py-12 lg:py-20">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-start">
            {/* Product Image */}
            <div className="relative aspect-square bg-gradient-to-br from-secondary/50 to-secondary/30 rounded-2xl overflow-hidden">
              <div className="absolute inset-0 spiral-bg opacity-40" />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-48 h-64 rounded-xl bg-secondary/80 border border-border/40 flex items-center justify-center">
                  <span className="text-sm text-muted-foreground text-center px-4">
                    Product<br />Image
                  </span>
                </div>
              </div>
              <div className="absolute top-6 left-6">
                <Badge className="bg-primary hover:bg-primary text-primary-foreground">
                  Tester Access
                </Badge>
              </div>
            </div>

            {/* Product Info */}
            <div className="space-y-8">
              <div>
                <h1 className="text-3xl sm:text-4xl font-bold tracking-tight mb-2">
                  Crafted Curl Leave-In Conditioner
                </h1>
                <p className="text-lg text-muted-foreground">
                  Lightweight hydration and definition for all curl patterns
                </p>
              </div>

              {/* What It Does */}
              <div>
                <h2 className="text-sm font-semibold text-foreground uppercase tracking-wider mb-4">
                  What It Does
                </h2>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <svg className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="text-muted-foreground">Provides lightweight hydration that absorbs without residue</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <svg className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="text-muted-foreground">Creates film-forming definition that maintains curl structure</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <svg className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="text-muted-foreground">Supports low-buildup routine for long-term hair health</span>
                  </li>
                </ul>
              </div>

              {/* CTA */}
              <div className="pt-4">
                <Link href="/testers">
                  <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                    Join Tester Program
                  </Button>
                </Link>
                <p className="text-xs text-muted-foreground mt-3">Limited to 30 testers. No spam.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Details Grid */}
      <section className="py-12 lg:py-20 bg-card/30">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Who It's For */}
            <div className="bg-card border border-border/60 rounded-xl p-6">
              <h3 className="text-base font-semibold mb-4">Who It&apos;s For</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>All curl patterns from wavy to coily</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>Low to high porosity hair</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>Fine to medium density hair</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>Those seeking lightweight definition</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>Athletes and active lifestyles</span>
                </li>
              </ul>
            </div>

            {/* Who It May Not Be For */}
            <div className="bg-card border border-border/60 rounded-xl p-6">
              <h3 className="text-base font-semibold mb-4">Who It May Not Be For</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-muted-foreground/50">•</span>
                  <span>Those seeking maximum hold (try our gel)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-muted-foreground/50">•</span>
                  <span>Very coarse hair needing intense moisture</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-muted-foreground/50">•</span>
                  <span>Those sensitive to aloe or plant extracts</span>
                </li>
              </ul>
            </div>

            {/* Porosity Guidance */}
            <div className="bg-card border border-border/60 rounded-xl p-6">
              <h3 className="text-base font-semibold mb-4">Porosity Guidance</h3>
              <ul className="space-y-3 text-sm text-muted-foreground">
                <li>
                  <span className="font-medium text-foreground">Low Porosity:</span>
                  <span className="block mt-1">Use lighter amounts. Apply to damp, not soaking hair.</span>
                </li>
                <li>
                  <span className="font-medium text-foreground">Medium Porosity:</span>
                  <span className="block mt-1">Standard application. Works as your daily driver.</span>
                </li>
                <li>
                  <span className="font-medium text-foreground">High Porosity:</span>
                  <span className="block mt-1">May layer with cream or oil for added moisture retention.</span>
                </li>
              </ul>
            </div>

            {/* Performance Mechanism */}
            <div className="bg-card border border-border/60 rounded-xl p-6">
              <h3 className="text-base font-semibold mb-4">Performance Mechanism</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Water-dominant formula with film-forming polysaccharides that coat the hair shaft, providing slip and definition. Controlled humectants attract moisture without over-hydrating. The olive-derived emulsifier system ensures even distribution without heavy residue.
              </p>
            </div>

            {/* Environmental Notes */}
            <div className="bg-card border border-border/60 rounded-xl p-6">
              <h3 className="text-base font-semibold mb-4">Environmental Notes</h3>
              <ul className="space-y-3 text-sm text-muted-foreground">
                <li>
                  <span className="font-medium text-foreground">Humid Climate:</span>
                  <span className="block mt-1">Film formers help maintain definition in moisture-rich air.</span>
                </li>
                <li>
                  <span className="font-medium text-foreground">Dry Climate:</span>
                  <span className="block mt-1">Humectants draw moisture to hair. Consider adding a sealant layer.</span>
                </li>
              </ul>
            </div>

            {/* Sensitivity */}
            <div className="bg-card border border-border/60 rounded-xl p-6">
              <h3 className="text-base font-semibold mb-4">Sensitivity + Patch Test</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                For external cosmetic use only. Apply a small amount to inner arm and wait 24 hours before full use. Discontinue if irritation occurs. Keep away from eyes.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How To Use */}
      <section className="py-12 lg:py-20">
        <div className="container mx-auto px-6 lg:px-12">
          <h2 className="text-2xl font-bold tracking-tight mb-8">How To Use</h2>
          
          <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
            <div className="space-y-6">
              <h3 className="text-lg font-semibold">Air Dry (Recommended)</h3>
              <ol className="space-y-4 text-muted-foreground">
                <li className="flex gap-4">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/20 text-primary text-sm font-medium flex items-center justify-center">1</span>
                  <span>Start with clean, damp hair. Section if needed for even distribution.</span>
                </li>
                <li className="flex gap-4">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/20 text-primary text-sm font-medium flex items-center justify-center">2</span>
                  <span>Apply leave-in from mid-lengths to ends, avoiding the scalp.</span>
                </li>
                <li className="flex gap-4">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/20 text-primary text-sm font-medium flex items-center justify-center">3</span>
                  <span>Distribute using praying hands or rake-and-shake technique.</span>
                </li>
                <li className="flex gap-4">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/20 text-primary text-sm font-medium flex items-center justify-center">4</span>
                  <span>Allow to air dry completely. Do not touch while drying.</span>
                </li>
                <li className="flex gap-4">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/20 text-primary text-sm font-medium flex items-center justify-center">5</span>
                  <span>Once dry, scrunch to break the cast for soft, defined curls.</span>
                </li>
              </ol>
            </div>
            
            <div className="space-y-6">
              <h3 className="text-lg font-semibold">Diffuser Option</h3>
              <ol className="space-y-4 text-muted-foreground">
                <li className="flex gap-4">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/20 text-primary text-sm font-medium flex items-center justify-center">1</span>
                  <span>Follow steps 1-3 from air dry method above.</span>
                </li>
                <li className="flex gap-4">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/20 text-primary text-sm font-medium flex items-center justify-center">2</span>
                  <span>Set diffuser to low heat and low speed to prevent frizz.</span>
                </li>
                <li className="flex gap-4">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/20 text-primary text-sm font-medium flex items-center justify-center">3</span>
                  <span>Cup curls gently in the diffuser, lifting toward the scalp.</span>
                </li>
                <li className="flex gap-4">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/20 text-primary text-sm font-medium flex items-center justify-center">4</span>
                  <span>Dry to 80-90%, then allow to finish air drying.</span>
                </li>
                <li className="flex gap-4">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/20 text-primary text-sm font-medium flex items-center justify-center">5</span>
                  <span>Scrunch to break any cast and reveal defined curls.</span>
                </li>
              </ol>
            </div>
          </div>
        </div>
      </section>

      {/* Ingredients */}
      <section className="py-12 lg:py-20 bg-card/30">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl">
            <h2 className="text-2xl font-bold tracking-tight mb-4">Ingredient List</h2>
            <p className="text-sm text-muted-foreground mb-6">
              INCI format, listed in descending order of concentration.
            </p>
            <div className="bg-card border border-border/60 rounded-xl p-6">
              <p className="text-sm text-muted-foreground leading-relaxed">
                {ingredients.join(', ')}.
              </p>
            </div>
            <p className="text-xs text-muted-foreground mt-4">
              Water-based systems require preservatives for safety. Our preservation system meets cosmetic safety standards.
            </p>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-12 lg:py-20">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl">
            <h2 className="text-2xl font-bold tracking-tight mb-8">Frequently Asked Questions</h2>
            
            <Accordion type="single" collapsible className="w-full space-y-4">
              {faqs.map((faq, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="bg-card border border-border/60 rounded-lg px-6 data-[state=open]:border-primary/30"
                >
                  <AccordionTrigger className="text-left text-base font-medium hover:no-underline">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 lg:py-24 bg-card/30">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-xl mx-auto text-center">
            <h2 className="text-2xl font-bold tracking-tight mb-4">
              Ready to Try?
            </h2>
            <p className="text-muted-foreground mb-8">
              Join our tester program for early access to the Crafted Curl Leave-In Conditioner.
            </p>
            <Link href="/testers">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
                Join Tester Program
              </Button>
            </Link>
            <p className="text-xs text-muted-foreground mt-4">Limited to 30 testers. No spam.</p>
          </div>
        </div>
      </section>
    </div>
  )
}
