import { Metadata } from 'next'
import { Badge } from '@/components/ui/badge'
import { EmailCapture } from '@/components/email-capture'

export const metadata: Metadata = {
  title: 'Crafted Curl Gel | CurlLoom',
  description: 'Long-lasting structural hold with humidity resistance. Coming soon—sign up to be notified when available.',
  openGraph: {
    title: 'Crafted Curl Gel | CurlLoom',
    description: 'Long-lasting structural hold with humidity resistance. Coming soon—sign up to be notified when available.',
  },
}

export default function GelPage() {
  return (
    <div className="flex flex-col min-h-[60vh]">
      {/* Hero Section */}
      <section className="py-12 lg:py-20 flex-1">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-start">
            {/* Product Image */}
            <div className="relative aspect-square bg-gradient-to-br from-secondary/50 to-secondary/30 rounded-2xl overflow-hidden">
              <div className="absolute inset-0 spiral-bg opacity-40" />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-48 h-64 rounded-xl bg-secondary/80 border border-border/40 flex items-center justify-center">
                  <span className="text-sm text-muted-foreground text-center px-4">
                    Product<br />Image
                  </span>
                </div>
              </div>
              <div className="absolute top-6 left-6">
                <Badge variant="outline" className="border-muted-foreground/30 text-muted-foreground">
                  Coming Soon
                </Badge>
              </div>
            </div>

            {/* Product Info */}
            <div className="space-y-8">
              <div>
                <h1 className="text-3xl sm:text-4xl font-bold tracking-tight mb-2">
                  Crafted Curl Gel
                </h1>
                <p className="text-lg text-muted-foreground">
                  Long-lasting structural hold for defined, lasting styles
                </p>
              </div>

              {/* Preview Features */}
              <div>
                <h2 className="text-sm font-semibold text-foreground uppercase tracking-wider mb-4">
                  Coming Features
                </h2>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <svg className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="text-muted-foreground">Long-lasting structural hold that maintains definition</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <svg className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="text-muted-foreground">Humidity-resistant finish for all-day style integrity</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <svg className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="text-muted-foreground">Flake-free formulation for clean, defined results</span>
                  </li>
                </ul>
              </div>

              {/* Notify Me */}
              <div className="pt-4">
                <p className="text-muted-foreground mb-4">
                  This product is currently in development. Sign up to be notified when it becomes available.
                </p>
                <EmailCapture variant="notify" productName="Crafted Curl Gel" className="max-w-md" />
                <p className="text-xs text-muted-foreground mt-3">No spam. Product updates only.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
