import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Contact | CurlLoom',
  description: 'Get in touch with CurlLoom. Questions about products, ingredients, or the tester program? We\'re here to help.',
  openGraph: {
    title: 'Contact | CurlLoom',
    description: 'Get in touch with CurlLoom. Questions about products, ingredients, or the tester program? We\'re here to help.',
  },
}

export default function ContactLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
