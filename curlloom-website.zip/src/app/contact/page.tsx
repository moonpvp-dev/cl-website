'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'

const subjectOptions = [
  { value: 'product-question', label: 'Product Question' },
  { value: 'tester-program', label: 'Tester Program Inquiry' },
  { value: 'order-status', label: 'Order Status' },
  { value: 'ingredient-info', label: 'Ingredient Information' },
  { value: 'partnership', label: 'Partnership or Collaboration' },
  { value: 'feedback', label: 'Product Feedback' },
  { value: 'other', label: 'Other' },
]

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    customSubject: '',
    message: '',
  })
  const [status, setStatus] = useState<'idle' | 'loading' | 'success'>('idle')

  const isOtherSelected = formData.subject === 'other'

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setStatus('loading')
    
    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1000))
    
    setStatus('success')
    setFormData({ name: '', email: '', subject: '', customSubject: '', message: '' })
  }

  const getFinalSubject = () => {
    if (isOtherSelected) {
      return formData.customSubject
    }
    const selectedOption = subjectOptions.find(opt => opt.value === formData.subject)
    return selectedOption?.label || ''
  }

  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-6">
              Get in Touch
            </h1>
            <p className="text-lg text-muted-foreground">
              Questions about products, ingredients, or the tester program? We&apos;re here to help.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Form & Info */}
      <section className="py-12 lg:py-20 bg-card/30">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-4xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-12">
              {/* Form */}
              <div>
                <h2 className="text-xl font-bold tracking-tight mb-6">Send a Message</h2>
                
                {status === 'success' ? (
                  <div className="bg-card border border-primary/30 rounded-xl p-8 text-center">
                    <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                      <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <h3 className="text-lg font-semibold mb-2">Message Sent</h3>
                    <p className="text-muted-foreground">
                      Thanks for reaching out. We&apos;ll get back to you as soon as possible.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium mb-2">
                        Name
                      </label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        required
                        className="bg-card border-border focus:border-primary focus:ring-primary/20"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium mb-2">
                        Email
                      </label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        required
                        className="bg-card border-border focus:border-primary focus:ring-primary/20"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="subject" className="block text-sm font-medium mb-2">
                        Subject
                      </label>
                      <select
                        id="subject"
                        value={formData.subject}
                        onChange={(e) => setFormData({ ...formData, subject: e.target.value, customSubject: '' })}
                        required
                        className="w-full h-10 px-3 py-2 bg-card border border-border rounded-md text-sm text-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 transition-colors"
                      >
                        <option value="" disabled>Select a subject</option>
                        {subjectOptions.map((option) => (
                          <option key={option.value} value={option.value}>
                            {option.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Custom Subject Input - shown when "Other" is selected */}
                    {isOtherSelected && (
                      <div className="animate-in slide-in-from-top-2 duration-200">
                        <label htmlFor="customSubject" className="block text-sm font-medium mb-2">
                          Please specify
                        </label>
                        <Input
                          id="customSubject"
                          value={formData.customSubject}
                          onChange={(e) => setFormData({ ...formData, customSubject: e.target.value })}
                          placeholder="Enter your subject"
                          required
                          className="bg-card border-border focus:border-primary focus:ring-primary/20"
                        />
                      </div>
                    )}
                    
                    <div>
                      <label htmlFor="message" className="block text-sm font-medium mb-2">
                        Message
                      </label>
                      <Textarea
                        id="message"
                        rows={5}
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        required
                        className="bg-card border-border focus:border-primary focus:ring-primary/20 resize-none"
                      />
                    </div>
                    
                    <Button
                      type="submit"
                      disabled={status === 'loading' || (isOtherSelected && !formData.customSubject)}
                      className="w-full bg-primary hover:bg-primary/90"
                    >
                      {status === 'loading' ? 'Sending...' : 'Send Message'}
                    </Button>
                  </form>
                )}
              </div>
              
              {/* Info */}
              <div className="space-y-8">
                <div>
                  <h2 className="text-xl font-bold tracking-tight mb-6">Quick Links</h2>
                  <div className="space-y-4">
                    <a
                      href="/faq"
                      className="flex items-center gap-3 p-4 bg-card border border-border/60 rounded-xl hover:border-primary/30 transition-colors"
                    >
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <svg className="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </div>
                      <div>
                        <span className="font-medium">FAQ</span>
                        <span className="block text-sm text-muted-foreground">Find answers to common questions</span>
                      </div>
                    </a>
                    
                    <a
                      href="/testers"
                      className="flex items-center gap-3 p-4 bg-card border border-border/60 rounded-xl hover:border-primary/30 transition-colors"
                    >
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <svg className="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                        </svg>
                      </div>
                      <div>
                        <span className="font-medium">Testers</span>
                        <span className="block text-sm text-muted-foreground">Join the tester program</span>
                      </div>
                    </a>
                    
                    <a
                      href="/ingredients"
                      className="flex items-center gap-3 p-4 bg-card border border-border/60 rounded-xl hover:border-primary/30 transition-colors"
                    >
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <svg className="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                        </svg>
                      </div>
                      <div>
                        <span className="font-medium">Ingredients & Standards</span>
                        <span className="block text-sm text-muted-foreground">Learn about our formulation approach</span>
                      </div>
                    </a>
                  </div>
                </div>
                
                <div className="bg-card border border-border/60 rounded-xl p-6">
                  <h3 className="font-semibold mb-3">Response Time</h3>
                  <p className="text-sm text-muted-foreground">
                    We typically respond within 1-2 business days. For urgent matters, please note that in the subject line.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
