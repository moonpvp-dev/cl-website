import Link from 'next/link'
import Image from 'next/image'
import { Button } from '@/components/ui/button'
import { ProductCard } from '@/components/product-card'
import { EmailCapture } from '@/components/email-capture'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'

const products = [
  {
    name: 'Crafted Curl Leave-In Conditioner',
    status: 'tester' as const,
    bullets: [
      'Lightweight hydration without residue',
      'Film-forming definition that lasts',
      'Low-buildup formula for regular use',
    ],
    href: '/product/leave-in-conditioner',
  },
  {
    name: 'Crafted Curl Curl Cream',
    status: 'coming-soon' as const,
    bullets: [
      'Enhanced curl definition',
      'Flexible hold with memory',
      'Frizz control for humid conditions',
    ],
    href: '/product/curl-cream',
  },
  {
    name: 'Crafted Curl Gel',
    status: 'coming-soon' as const,
    bullets: [
      'Long-lasting structural hold',
      'Humidity-resistant finish',
      'Flake-free formulation',
    ],
    href: '/product/gel',
  },
]

const educationContent = [
  {
    title: 'Low Porosity & Buildup',
    content: 'Low porosity hair has tightly bound cuticles that resist moisture absorption, making product buildup a common concern. Our lightweight, water-dominant formulas are designed to penetrate without sitting on the surface. The key is using products that hydrate without heavy oils or butters that can create barriers. Our formulation philosophy prioritizes film-forming ingredients that provide definition while remaining easily removable on wash day.',
  },
  {
    title: 'Humidity & Frizz Control',
    content: 'Humidity causes frizz when hair absorbs excess moisture from the air, disrupting hydrogen bonds in the hair shaft. Our approach uses controlled humectants that attract just enough moisture to maintain hydration without over-saturating. Film-forming polysaccharides create a light barrier that helps maintain your style\'s integrity in varying conditions. The result is definition that adapts to your environment rather than fighting against it.',
  },
  {
    title: 'Hold & Finish Expectations',
    content: 'Different curl patterns and styles require different hold levels. A leave-in conditioner provides light definition with natural movement. Curl cream adds structure with flexibility, ideal for wash-and-go styles. Gel delivers maximum hold for defined, longer-lasting styles. Many curlies layer products to achieve their desired finish—starting with hydration and building hold as needed. We design our products to work together seamlessly while remaining effective individually.',
  },
]

export default function Home() {
  return (
    <div className="flex flex-col">
      {/* Section 1: Hero */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
        {/* Spiral Watermark Background */}
        <div className="absolute inset-0 spiral-bg opacity-30" />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background/50 to-background" />
        
        <div className="relative container mx-auto px-6 lg:px-12 py-24 text-center">
          <div className="max-w-4xl mx-auto space-y-8">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-balance">
              Curl care engineered for{' '}
              <span className="gradient-text">performance.</span>
            </h1>
            
            <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto text-balance">
              Lightweight definition and controlled hold—built through disciplined formulation and community insight.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
              <Link href="/shop">
                <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground px-8">
                  Shop
                </Button>
              </Link>
              <Link href="/routine">
                <Button size="lg" variant="outline" className="border-border hover:bg-secondary px-8">
                  Get Your Routine
                </Button>
              </Link>
            </div>
            
            {/* Trust Micro-Row */}
            <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 pt-8 text-sm text-muted-foreground">
              <span className="flex items-center gap-2">
                <svg className="w-4 h-4 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                Low-buildup feel
              </span>
              <span className="flex items-center gap-2">
                <svg className="w-4 h-4 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                Humidity-aware performance
              </span>
              <span className="flex items-center gap-2">
                <svg className="w-4 h-4 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                Patch-test recommended
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Section 2: Featured Products */}
      <section className="py-24 lg:py-32 bg-card/30">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
              The Crafted Curl Line
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Performance-focused formulations designed for definition, hold, and long-term hair health.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {products.map((product) => (
              <ProductCard
                key={product.name}
                name={product.name}
                status={product.status}
                bullets={product.bullets}
                href={product.href}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Section 3: Get Your Routine (Highlighted) */}
      <section className="py-24 lg:py-32 relative overflow-hidden">
        {/* Purple Glow Anchor */}
        <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-primary/5" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/10 rounded-full blur-[120px] opacity-30" />
        
        <div className="relative container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto text-center space-y-8">
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">
              Find Your Curl Routine.
            </h2>
            
            <p className="text-lg text-muted-foreground max-w-xl mx-auto">
              Answer a few questions. Get a tailored routine and product pairing.
            </p>
            
            <Link href="/routine">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground px-10">
                Start Routine Builder
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Section 4: Education (Accordion) */}
      <section className="py-24 lg:py-32 bg-card/30">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
                Curl Care Fundamentals
              </h2>
              <p className="text-muted-foreground">
                Understanding your hair is the first step to better results.
              </p>
            </div>
            
            <Accordion type="single" collapsible className="w-full space-y-4">
              {educationContent.map((item, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="bg-card border border-border/60 rounded-lg px-6 data-[state=open]:border-primary/30"
                >
                  <AccordionTrigger className="text-left text-base font-medium hover:no-underline">
                    {item.title}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed">
                    {item.content}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* Section 5: Formulation Philosophy */}
      <section className="py-24 lg:py-32">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-2 gap-12 lg:gap-16 items-center">
              <div>
                <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-6">
                  Formulation Philosophy
                </h2>
                <p className="text-muted-foreground mb-8">
                  Every ingredient serves a purpose. No fillers, no compromises—just disciplined formulation built for performance.
                </p>
                <Link href="/ingredients">
                  <Button variant="outline" className="border-border hover:bg-secondary">
                    Explore Ingredients & Standards
                  </Button>
                </Link>
              </div>
              
              <div className="bg-card border border-border/60 rounded-xl p-8 space-y-4">
                {[
                  'Water-dominant base',
                  'Controlled humectants',
                  'Lightweight refined oils',
                  'Film-forming polysaccharides',
                  'Preservative discipline',
                ].map((item, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <svg className="w-4 h-4 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <span className="text-foreground">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 6: Testers */}
      <section className="py-24 lg:py-32 bg-card/30">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-6">
              Built With Community
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              We don&apos;t guess what works—we ask. Our tester program puts products in the hands of real curlies before they launch. Their feedback shapes every iteration.
            </p>
            
            <div className="grid sm:grid-cols-3 gap-6 mb-10">
              <div className="bg-card border border-border/60 rounded-xl p-6 text-left">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                  </svg>
                </div>
                <h3 className="font-semibold mb-1">Community-First</h3>
                <p className="text-sm text-muted-foreground">Real feedback drives every iteration</p>
              </div>
              
              <div className="bg-card border border-border/60 rounded-xl p-6 text-left">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="font-semibold mb-1">Limited Spots</h3>
                <p className="text-sm text-muted-foreground">Only 30 testers per product phase</p>
              </div>
              
              <div className="bg-card border border-border/60 rounded-xl p-6 text-left">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <h3 className="font-semibold mb-1">Early Access</h3>
                <p className="text-sm text-muted-foreground">First to try new formulations</p>
              </div>
            </div>
            
            <Link href="/testers">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
                Join Tester Program
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Section 7: Founder */}
      <section className="py-24 lg:py-32">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-2xl mx-auto text-center">
            <div className="relative w-24 h-24 rounded-full overflow-hidden mx-auto mb-6 ring-4 ring-primary/20">
              <Image
                src="/parker-deluca.jpg"
                alt="Parker DeLuca - Founder of CurlLoom"
                fill
                className="object-cover"
                priority
              />
            </div>
            <h2 className="text-2xl font-bold tracking-tight mb-1">Parker DeLuca</h2>
            <p className="text-primary text-sm font-medium mb-6">Founder, CurlLoom</p>
            <p className="text-muted-foreground text-lg">
              Community-focused, performance-driven brand builder.
            </p>
          </div>
        </div>
      </section>
    </div>
  )
}
