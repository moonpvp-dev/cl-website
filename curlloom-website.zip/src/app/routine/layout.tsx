import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Get Your Routine | CurlLoom',
  description: 'Answer a few questions and get a personalized curl care routine with product recommendations tailored to your hair.',
  openGraph: {
    title: 'Get Your Routine | CurlLoom',
    description: 'Answer a few questions and get a personalized curl care routine with product recommendations tailored to your hair.',
  },
}

export default function RoutineLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
