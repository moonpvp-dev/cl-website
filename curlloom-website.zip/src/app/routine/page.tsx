'use client'

import { useState } from 'react'
import { Metadata } from 'next'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { EmailCapture } from '@/components/email-capture'
import Link from 'next/link'

const questions = [
  {
    id: 'pattern',
    question: 'What\'s your hair pattern?',
    options: [
      { value: 'wavy', label: 'Straight-ish waves', description: 'Loose S-shape, often at ends' },
      { value: 'loose-curls', label: 'Loose curls', description: 'Defined curls, larger circumference' },
      { value: 'tight-curls', label: 'Tight curls', description: 'Smaller, springy curls' },
      { value: 'coily', label: 'Coily', description: 'Tight zig-zag pattern' },
    ],
  },
  {
    id: 'porosity',
    question: 'What\'s your hair porosity?',
    options: [
      { value: 'low', label: 'Low', description: 'Products sit on top, takes time to absorb water' },
      { value: 'medium', label: 'Medium', description: 'Balanced absorption, most common' },
      { value: 'high', label: 'High', description: 'Absorbs quickly, loses moisture fast' },
      { value: 'unsure', label: 'Not sure', description: 'We\'ll make a versatile recommendation' },
    ],
  },
  {
    id: 'thickness',
    question: 'What\'s your strand thickness?',
    options: [
      { value: 'fine', label: 'Fine', description: 'Delicate, easily weighed down' },
      { value: 'medium', label: 'Medium', description: 'Balanced, versatile' },
      { value: 'coarse', label: 'Coarse', description: 'Strong, takes more product' },
    ],
  },
  {
    id: 'density',
    question: 'What\'s your hair density?',
    options: [
      { value: 'sparse', label: 'Sparse', description: 'Scalp easily visible' },
      { value: 'average', label: 'Average', description: 'Moderate fullness' },
      { value: 'dense', label: 'Dense', description: 'Full, lots of hair' },
    ],
  },
  {
    id: 'goal',
    question: 'What\'s your primary hair goal?',
    options: [
      { value: 'definition', label: 'Definition', description: 'Clear, visible curl pattern' },
      { value: 'volume', label: 'Volume', description: 'Fullness and body' },
      { value: 'moisture', label: 'Moisture', description: 'Hydration and softness' },
      { value: 'hold', label: 'Hold', description: 'Long-lasting style' },
    ],
  },
  {
    id: 'issue',
    question: 'What\'s your main hair issue?',
    options: [
      { value: 'frizz', label: 'Frizz', description: 'Unruly, undefined texture' },
      { value: 'dryness', label: 'Dryness', description: 'Lacks moisture, feels rough' },
      { value: 'definition', label: 'Lack of definition', description: 'Curls aren\'t distinct' },
      { value: 'buildup', label: 'Product buildup', description: 'Heavy, weighed down feeling' },
    ],
  },
  {
    id: 'climate',
    question: 'What\'s your climate?',
    options: [
      { value: 'humid', label: 'Humid', description: 'High moisture in air' },
      { value: 'dry', label: 'Dry', description: 'Low humidity, arid' },
      { value: 'mixed', label: 'Mixed/Seasonal', description: 'Varies throughout the year' },
    ],
  },
  {
    id: 'frequency',
    question: 'How often do you wash your hair?',
    options: [
      { value: 'daily', label: 'Daily', description: 'Every day' },
      { value: 'often', label: 'Every 2-3 days', description: 'A few times a week' },
      { value: 'weekly', label: 'Weekly', description: 'Once a week' },
      { value: 'less', label: 'Less often', description: 'Every 2+ weeks' },
    ],
  },
  {
    id: 'sensitivity',
    question: 'Do you have scalp or skin sensitivity?',
    options: [
      { value: 'none', label: 'No sensitivity', description: 'No issues with most products' },
      { value: 'mild', label: 'Mild sensitivity', description: 'Occasional reactions' },
      { value: 'sensitive', label: 'Sensitive', description: 'Frequent reactions to products' },
      { value: 'very', label: 'Very sensitive', description: 'Must be very careful with ingredients' },
    ],
  },
  {
    id: 'finish',
    question: 'What finish do you prefer?',
    options: [
      { value: 'natural', label: 'Natural/soft', description: 'Moveable, touchable curls' },
      { value: 'defined', label: 'Defined/crisp', description: 'Structured, clear curl pattern' },
      { value: 'maximum', label: 'Maximum hold', description: 'Strong, long-lasting style' },
    ],
  },
]

type Answers = Record<string, string>

interface RoutineResult {
  matchStrength: 'High' | 'Medium'
  primaryProduct: string
  secondaryProduct: string
  optionalProduct: string
  adjustments: string[]
  whyRecommended: string
}

function generateRoutine(answers: Answers): RoutineResult {
  const adjustments: string[] = []
  let matchStrength: 'High' | 'Medium' = 'High'
  
  // Adjustments based on porosity
  if (answers.porosity === 'low') {
    adjustments.push('Low porosity → use lighter amounts to prevent buildup')
  }
  
  // Adjustments based on thickness
  if (answers.thickness === 'fine') {
    adjustments.push('Fine hair → avoid stacking too many products')
  }
  
  // Adjustments based on climate
  if (answers.climate === 'humid') {
    adjustments.push('High humidity → emphasize film-forming products for definition')
  } else if (answers.climate === 'dry') {
    adjustments.push('Dry climate → increase hydration layering')
  }
  
  // Match strength based on goal alignment
  if (answers.goal === 'hold' && answers.finish === 'maximum') {
    matchStrength = 'Medium'
  }
  
  // Generate why recommended
  const whyParts = []
  whyParts.push(`Your ${answers.pattern.replace('-', ' ')} pattern benefits from lightweight definition.`)
  
  if (answers.porosity === 'low') {
    whyParts.push('Low porosity hair responds well to our water-dominant, easily-absorbed formula.')
  } else if (answers.porosity === 'high') {
    whyParts.push('High porosity hair gets moisture retention from our film-forming ingredients.')
  }
  
  if (answers.goal === 'definition') {
    whyParts.push('Your goal of enhanced definition aligns with our formulation approach.')
  }
  
  return {
    matchStrength,
    primaryProduct: 'Leave-In Conditioner (Tester Access)',
    secondaryProduct: 'Curl Cream (Coming Soon)',
    optionalProduct: 'Crafted Curl Gel (Coming Soon — Notify Me)',
    adjustments,
    whyRecommended: whyParts.join(' '),
  }
}

export default function RoutinePage() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Answers>({})
  const [showResults, setShowResults] = useState(false)
  const [expandedWhy, setExpandedWhy] = useState(false)
  
  const progress = ((currentQuestion) / questions.length) * 100
  
  const handleAnswer = (questionId: string, value: string) => {
    const newAnswers = { ...answers, [questionId]: value }
    setAnswers(newAnswers)
    
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    } else {
      setShowResults(true)
    }
  }
  
  const handleBack = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
    }
  }
  
  const handleRestart = () => {
    setCurrentQuestion(0)
    setAnswers({})
    setShowResults(false)
    setExpandedWhy(false)
  }
  
  const question = questions[currentQuestion]
  const result = showResults ? generateRoutine(answers) : null
  
  if (showResults && result) {
    return (
      <div className="flex flex-col min-h-[80vh]">
        {/* Results Header */}
        <section className="py-12 lg:py-16 border-b border-border/40">
          <div className="container mx-auto px-6 lg:px-12">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
                Your Routine Summary
              </h1>
              <p className="text-muted-foreground">
                Based on your answers, here&apos;s a personalized routine recommendation.
              </p>
            </div>
          </div>
        </section>
        
        {/* Results Content */}
        <section className="py-12 lg:py-16">
          <div className="container mx-auto px-6 lg:px-12">
            <div className="max-w-4xl mx-auto space-y-12">
              {/* Wash Day */}
              <div>
                <h2 className="text-xl font-bold mb-6">Wash Day</h2>
                <div className="bg-card border border-border/60 rounded-xl overflow-hidden">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border/40">
                        <th className="px-6 py-4 text-left text-sm font-medium text-muted-foreground">Step</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-muted-foreground">Product(s)</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-muted-foreground">Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border/40">
                      <tr>
                        <td className="px-6 py-4 text-sm">1. Cleanse</td>
                        <td className="px-6 py-4 text-sm text-muted-foreground">Your preferred cleanser</td>
                        <td className="px-6 py-4 text-sm text-muted-foreground">As needed</td>
                      </tr>
                      <tr>
                        <td className="px-6 py-4 text-sm">2. Condition</td>
                        <td className="px-6 py-4 text-sm text-muted-foreground">Your preferred conditioner</td>
                        <td className="px-6 py-4 text-sm text-muted-foreground">As needed</td>
                      </tr>
                      <tr>
                        <td className="px-6 py-4 text-sm">3. Leave-In</td>
                        <td className="px-6 py-4 text-sm text-primary font-medium">Crafted Curl Leave-In</td>
                        <td className="px-6 py-4 text-sm text-muted-foreground">Quarter to golf ball size</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <p className="text-sm text-muted-foreground mt-4">
                  <strong>Air dry:</strong> Apply leave-in to damp hair, distribute evenly, allow to dry completely. Scrunch to break cast.<br />
                  <strong>Diffuser:</strong> Low heat, low speed. Dry to 80-90%, finish air drying.
                </p>
              </div>
              
              {/* Styling Day */}
              <div>
                <h2 className="text-xl font-bold mb-6">Styling Day</h2>
                <div className="bg-card border border-border/60 rounded-xl p-6 space-y-4">
                  <div>
                    <h3 className="font-medium mb-2">Products</h3>
                    <p className="text-sm text-muted-foreground">Leave-In + Curl Cream (usually both, in that order)</p>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Technique</h3>
                    <p className="text-sm text-muted-foreground">Apply using praying hands, rake-and-shake, or scrunch method. Work in sections for even distribution.</p>
                  </div>
                </div>
              </div>
              
              {/* Refresh Day */}
              <div>
                <h2 className="text-xl font-bold mb-6">Refresh Day</h2>
                <div className="bg-card border border-border/60 rounded-xl p-6">
                  <p className="text-sm text-muted-foreground">
                    Mist hair with water until slightly damp. Apply a small amount of leave-in to frizzy or undefined areas. Scrunch gently to reactivate product. Air dry or diffuse.
                  </p>
                </div>
              </div>
              
              {/* Product Recommendations */}
              <div>
                <h2 className="text-xl font-bold mb-6">Product Recommendations</h2>
                <div className="grid sm:grid-cols-3 gap-4">
                  <div className="bg-card border border-primary/30 rounded-xl p-6">
                    <span className="text-xs font-medium text-primary uppercase tracking-wider">Primary</span>
                    <h3 className="font-medium mt-2 mb-1">Leave-In Conditioner</h3>
                    <p className="text-xs text-muted-foreground mb-3">Tester Access</p>
                    <Link href="/testers">
                      <Button size="sm" className="w-full bg-primary hover:bg-primary/90">
                        Join Program
                      </Button>
                    </Link>
                  </div>
                  <div className="bg-card border border-border/60 rounded-xl p-6">
                    <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Secondary</span>
                    <h3 className="font-medium mt-2 mb-1">Curl Cream</h3>
                    <p className="text-xs text-muted-foreground mb-3">Coming Soon</p>
                    <Link href="/product/curl-cream">
                      <Button size="sm" variant="outline" className="w-full">
                        Notify Me
                      </Button>
                    </Link>
                  </div>
                  <div className="bg-card border border-border/60 rounded-xl p-6">
                    <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Optional</span>
                    <h3 className="font-medium mt-2 mb-1">Crafted Curl Gel</h3>
                    <p className="text-xs text-muted-foreground mb-3">Coming Soon</p>
                    <Link href="/product/gel">
                      <Button size="sm" variant="outline" className="w-full">
                        Notify Me
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
              
              {/* Adjustment Tips */}
              {result.adjustments.length > 0 && (
                <div>
                  <h2 className="text-xl font-bold mb-6">Adjustment Tips</h2>
                  <div className="bg-card border border-border/60 rounded-xl p-6">
                    <ul className="space-y-3">
                      {result.adjustments.map((tip, index) => (
                        <li key={index} className="flex items-start gap-3 text-sm text-muted-foreground">
                          <svg className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          <span>{tip}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
              
              {/* Confidence Indicator */}
              <div>
                <h2 className="text-xl font-bold mb-6">Match Confidence</h2>
                <div className="bg-card border border-border/60 rounded-xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-sm text-muted-foreground">Match Strength</span>
                    <span className={`text-sm font-medium ${result.matchStrength === 'High' ? 'text-primary' : 'text-yellow-500'}`}>
                      {result.matchStrength}
                    </span>
                  </div>
                  <button
                    onClick={() => setExpandedWhy(!expandedWhy)}
                    className="flex items-center gap-2 text-sm text-primary hover:text-primary/80 transition-colors"
                  >
                    <span>{expandedWhy ? 'Hide' : 'Show'} why we recommended this</span>
                    <svg
                      className={`w-4 h-4 transition-transform ${expandedWhy ? 'rotate-180' : ''}`}
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                  {expandedWhy && (
                    <p className="text-sm text-muted-foreground mt-4 pt-4 border-t border-border/40">
                      {result.whyRecommended}
                    </p>
                  )}
                </div>
              </div>
              
              {/* Disclaimer */}
              <div className="bg-secondary/50 rounded-xl p-6">
                <p className="text-xs text-muted-foreground text-center">
                  For external cosmetic use only. Patch test recommended before full application. Results may vary based on individual hair characteristics.
                </p>
              </div>
              
              {/* Actions */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
                <Button onClick={handleRestart} variant="outline" className="border-border hover:bg-secondary">
                  Retake Quiz
                </Button>
                <Link href="/testers">
                  <Button className="w-full sm:w-auto bg-primary hover:bg-primary/90">
                    Join Tester Program
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </div>
    )
  }
  
  return (
    <div className="flex flex-col min-h-[80vh]">
      {/* Progress Bar */}
      <div className="sticky top-16 z-40 bg-background/80 backdrop-blur-xl border-b border-border/40">
        <div className="container mx-auto px-6 lg:px-12 py-4">
          <div className="max-w-2xl mx-auto">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Question {currentQuestion + 1} of {questions.length}</span>
              <span className="text-sm text-muted-foreground">{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} className="h-1 bg-secondary" />
          </div>
        </div>
      </div>
      
      {/* Question */}
      <section className="flex-1 py-12 lg:py-20">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-2xl mx-auto">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-8 text-center">
              {question.question}
            </h2>
            
            <div className="grid gap-3">
              {question.options.map((option) => (
                <button
                  key={option.value}
                  onClick={() => handleAnswer(question.id, option.value)}
                  className={`w-full text-left p-4 rounded-xl border transition-all duration-200 ${
                    answers[question.id] === option.value
                      ? 'border-primary bg-primary/10'
                      : 'border-border/60 bg-card hover:border-primary/50 hover:bg-card/80'
                  }`}
                >
                  <span className="font-medium">{option.label}</span>
                  <span className="block text-sm text-muted-foreground mt-1">{option.description}</span>
                </button>
              ))}
            </div>
            
            {/* Navigation */}
            <div className="flex justify-between mt-8">
              <Button
                onClick={handleBack}
                variant="ghost"
                disabled={currentQuestion === 0}
                className="text-muted-foreground hover:text-foreground"
              >
                Back
              </Button>
              {currentQuestion === questions.length - 1 && answers[question.id] && (
                <Button
                  onClick={() => setShowResults(true)}
                  className="bg-primary hover:bg-primary/90"
                >
                  See My Routine
                </Button>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
