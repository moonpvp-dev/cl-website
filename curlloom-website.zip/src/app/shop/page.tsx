import { Metadata } from 'next'
import Link from 'next/link'
import { ProductCard } from '@/components/product-card'

export const metadata: Metadata = {
  title: 'Shop | CurlLoom',
  description: 'Explore the Crafted Curl line—performance-focused formulations for lightweight definition and controlled hold.',
  openGraph: {
    title: 'Shop | CurlLoom',
    description: 'Explore the Crafted Curl line—performance-focused formulations for lightweight definition and controlled hold.',
  },
}

const products = [
  {
    name: 'Crafted Curl Leave-In Conditioner',
    subtitle: 'Lightweight hydration & definition',
    status: 'tester' as const,
    bullets: [
      'Lightweight hydration without residue',
      'Film-forming definition that lasts',
      'Low-buildup formula for regular use',
    ],
    href: '/product/leave-in-conditioner',
  },
  {
    name: 'Crafted Curl Curl Cream',
    subtitle: 'Enhanced definition & flexible hold',
    status: 'coming-soon' as const,
    bullets: [
      'Enhanced curl definition',
      'Flexible hold with memory',
      'Frizz control for humid conditions',
    ],
    href: '/product/curl-cream',
  },
  {
    name: 'Crafted Curl Gel',
    subtitle: 'Long-lasting structural hold',
    status: 'coming-soon' as const,
    bullets: [
      'Long-lasting structural hold',
      'Humidity-resistant finish',
      'Flake-free formulation',
    ],
    href: '/product/gel',
  },
]

export default function ShopPage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-6">
              The Crafted Curl Line
            </h1>
            <p className="text-lg text-muted-foreground max-w-xl">
              Performance-focused formulations designed for definition, hold, and long-term hair health. Each product is built through disciplined formulation and community feedback.
            </p>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-8 lg:py-16">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {products.map((product) => (
              <ProductCard
                key={product.name}
                name={product.name}
                subtitle={product.subtitle}
                status={product.status}
                bullets={product.bullets}
                href={product.href}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Routine CTA */}
      <section className="py-16 lg:py-24 bg-card/30">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-4">
              Not Sure Where to Start?
            </h2>
            <p className="text-muted-foreground mb-8">
              Take our routine builder quiz to get personalized product recommendations based on your hair type, goals, and environment.
            </p>
            <Link href="/routine">
              <button className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-3 rounded-lg font-medium transition-colors">
                Get Your Routine
              </button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
