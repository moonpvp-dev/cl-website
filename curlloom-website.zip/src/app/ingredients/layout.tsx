import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Ingredients & Standards | CurlLoom',
  description: 'Every ingredient serves a purpose. Learn about our water-dominant formulations with controlled actives for performance without excess.',
  openGraph: {
    title: 'Ingredients & Standards | CurlLoom',
    description: 'Every ingredient serves a purpose. Learn about our water-dominant formulations with controlled actives for performance without excess.',
  },
}

export { default } from './page'
