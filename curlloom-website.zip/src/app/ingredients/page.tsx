'use client'

import { useState } from 'react'
import { ChevronDown } from 'lucide-react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'

const formulaSections = [
  {
    id: 'base',
    title: 'Base System',
    items: [
      {
        name: 'Water-Dominant Base',
        description: 'Aqua forms the foundation, ensuring lightweight application and even distribution.',
      },
      {
        name: 'Aloe-Supported Hydration',
        description: 'Aloe Barbadensis Leaf Juice provides additional hydration and slip.',
      },
    ],
  },
  {
    id: 'humectants',
    title: 'Humectants',
    items: [
      {
        name: 'Propanediol',
        description: 'A controlled humectant that draws moisture without the stickiness of glycerin in high humidity.',
      },
      {
        name: 'Sodium PCA',
        description: 'A naturally occurring component of skin\'s NMF (Natural Moisturizing Factor), provides hydration support.',
      },
    ],
  },
  {
    id: 'film-formers',
    title: 'Film-Formers',
    items: [
      {
        name: 'Beta-Glucan',
        description: 'Polysaccharide that creates a flexible film for light hold and moisture retention.',
      },
      {
        name: 'Marshmallow Root Extract',
        description: 'Althaea Officinalis provides slip and contributes to film formation for curl definition.',
      },
    ],
  },
  {
    id: 'oils',
    title: 'Oils & Emollients',
    items: [
      {
        name: 'Grapeseed Oil',
        description: 'Vitis Vinifera seed oil: lightweight, non-greasy, provides slip without heavy residue.',
      },
      {
        name: 'Sunflower Seed Oil',
        description: 'Helianthus Annuus: light emollient rich in vitamin E, supports surface conditioning.',
      },
    ],
  },
  {
    id: 'emulsifiers',
    title: 'Emulsifier System',
    items: [
      {
        name: 'Olivem 1000',
        description: 'Cetearyl Olivate and Sorbitan Olivate: olive-derived emulsifier system, creates stable, elegant texture.',
      },
    ],
  },
  {
    id: 'support',
    title: 'Support Ingredients',
    items: [
      {
        name: 'Sodium Gluconate',
        description: 'Chelating agent that binds minerals, improves product stability in hard water.',
      },
      {
        name: 'Mixed Tocopherols',
        description: 'Vitamin E antioxidants that support oil stability and provide mild oxidative protection.',
      },
    ],
  },
  {
    id: 'preservation',
    title: 'Preservation',
    items: [
      {
        name: 'Geogard ECT',
        description: 'A broad-spectrum preservative system (Benzyl Alcohol, Glyceryl Caprylate, Glyceryl Undecylenate, Phenoxyethanol) approved for cosmetic use. Required for water-based products.',
      },
    ],
  },
]

const clarifications = [
  {
    title: 'Cosmetics act on the hair fiber surface only',
    description: 'They do not alter follicle biology or stimulate growth. Any improvement in appearance is due to surface conditioning and definition.',
  },
  {
    title: 'Water-based systems require preservatives for safety',
    description: 'Without preservation, water-based products can develop harmful bacteria and mold. We use approved preservative systems at effective concentrations.',
  },
  {
    title: 'We do not publish formula percentages',
    description: 'Exact ratios are proprietary. Full INCI lists are provided on product pages and packaging in descending order of concentration.',
  },
]

const notClaimed = [
  'Hair growth or regrowth',
  'Medical treatment or therapy',
  '"Chemical-free" (all matter is chemical)',
  '"Non-toxic" (meaningless without context)',
  'Dermatologist approval (unless verified)',
  'Cure for any condition',
]

export default function IngredientsPage() {
  const [openSections, setOpenSections] = useState<string[]>(['base'])

  const toggleSection = (id: string) => {
    setOpenSections(prev =>
      prev.includes(id)
        ? prev.filter(s => s !== id)
        : [...prev, id]
    )
  }

  return (
    <div className="flex flex-col">
      {/* Header */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-6">
              Ingredients & Standards
            </h1>
            <p className="text-lg text-muted-foreground">
              Every ingredient serves a purpose. We build from a water-dominant base with controlled actives for performance without excess.
            </p>
          </div>
        </div>
      </section>

      {/* Formula Architecture */}
      <section className="py-12 lg:py-20">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-8 text-center">
              Formula V3 Architecture
            </h2>

            <div className="space-y-3">
              {formulaSections.map((section) => (
                <div
                  key={section.id}
                  className="border border-border/60 rounded-xl overflow-hidden"
                >
                  <button
                    onClick={() => toggleSection(section.id)}
                    className="w-full flex items-center justify-between p-5 text-left hover:bg-card/50 transition-colors"
                  >
                    <span className="font-semibold text-primary">{section.title}</span>
                    <ChevronDown
                      className={`w-5 h-5 text-muted-foreground flex-shrink-0 transition-transform duration-200 ${
                        openSections.includes(section.id) ? 'rotate-180' : ''
                      }`}
                    />
                  </button>
                  {openSections.includes(section.id) && (
                    <div className="px-5 pb-5 space-y-4">
                      {section.items.map((item, index) => (
                        <div key={index} className="border-l-2 border-primary/30 pl-4">
                          <h4 className="font-medium text-foreground mb-1">{item.name}</h4>
                          <p className="text-sm text-muted-foreground">{item.description}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Important Clarifications */}
      <section className="py-12 lg:py-20 bg-card/30">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-8 text-center">
              Important Clarifications
            </h2>

            <div className="space-y-4">
              {clarifications.map((item, index) => (
                <div key={index} className="bg-card border border-border/60 rounded-xl p-6">
                  <h3 className="font-semibold mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* What We Don't Claim */}
      <section className="py-12 lg:py-20">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-8 text-center">
              What We Don&apos;t Claim
            </h2>

            <div className="bg-card border border-border/60 rounded-xl p-6">
              <ul className="space-y-3">
                {notClaimed.map((item, index) => (
                  <li key={index} className="flex items-center gap-3 text-muted-foreground">
                    <span className="text-red-500/70">✕</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 lg:py-24 bg-card/30">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-xl mx-auto text-center">
            <h2 className="text-2xl font-bold tracking-tight mb-4">
              Have questions about our ingredients?
            </h2>
            <p className="text-muted-foreground mb-8">
              We&apos;re happy to discuss formulation choices.
            </p>
            <Link href="/contact">
              <Button className="bg-primary hover:bg-primary/90">
                Contact Us
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
