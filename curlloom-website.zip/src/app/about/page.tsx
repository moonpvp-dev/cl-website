import { Metadata } from 'next'
import Link from 'next/link'
import Image from 'next/image'
import { Button } from '@/components/ui/button'

export const metadata: Metadata = {
  title: 'About | CurlLoom',
  description: 'Learn about CurlLoom—performance-focused curl care built on disciplined formulation and community insight.',
  openGraph: {
    title: 'About | CurlLoom',
    description: 'Learn about CurlLoom—performance-focused curl care built on disciplined formulation and community insight.',
  },
}

const values = [
  {
    title: 'Performance Over Trends',
    description: 'We formulate for results, not marketing buzzwords. Every ingredient earns its place in our formulas through demonstrated efficacy, not trendiness.',
  },
  {
    title: 'Community Integration',
    description: 'Real curlies test our products before they reach the public. Their feedback shapes our formulations, ensuring we build what people actually need.',
  },
  {
    title: 'Disciplined Formulation',
    description: 'We approach cosmetic formulation with rigor and transparency. No hidden ingredients, no exaggerated claims, no shortcuts.',
  },
  {
    title: 'Long-Term Thinking',
    description: 'We build for sustained hair health, not quick fixes. Low-buildup formulas support consistent routines without product fatigue.',
  },
]

export default function AboutPage() {
  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-6">
              Built Different.
            </h1>
            <p className="text-lg text-muted-foreground">
              CurlLoom exists because curl care deserved better—better formulation discipline, better community integration, better transparency.
            </p>
          </div>
        </div>
      </section>

      {/* Story */}
      <section className="py-12 lg:py-20 bg-card/30">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-8 text-center">
              Our Approach
            </h2>
            
            <div className="prose prose-lg prose-invert max-w-none text-center">
              <p className="text-muted-foreground leading-relaxed mb-6">
                CurlLoom started with a simple observation: the curl care market was filled with products that overpromised and underdelivered. Heavy butters that caused buildup. Formulas that worked in some climates but failed in others. Marketing claims that outpaced actual performance.
              </p>
              
              <p className="text-muted-foreground leading-relaxed mb-6">
                We took a different approach. Instead of chasing trends or filling products with trendy ingredients at trace levels, we focused on disciplined cosmetic formulation. Water-dominant bases. Controlled humectants. Film-forming ingredients that provide definition without stiffness. Everything serves a purpose.
              </p>
              
              <p className="text-muted-foreground leading-relaxed mb-6">
                But formulation is only half the equation. The other half is listening. Our tester program puts products in real hands before launch, gathering structured feedback that directly influences development. We don&apos;t guess what works—we ask.
              </p>
              
              <p className="text-muted-foreground leading-relaxed">
                The result: curl care that performs consistently, builds community trust through transparency, and supports long-term hair health through low-buildup formulation. No shortcuts. No exaggerations. Just honest, effective products.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Founder */}
      <section className="py-12 lg:py-20">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-12">
              Meet the Founder
            </h2>
            
            <div className="flex flex-col items-center">
              {/* Profile Image */}
              <div className="relative w-40 h-40 rounded-full overflow-hidden mb-6 ring-4 ring-primary/20">
                <Image
                  src="/parker-deluca.jpg"
                  alt="Parker DeLuca - Founder of CurlLoom"
                  fill
                  className="object-cover"
                  priority
                />
              </div>
              
              <h3 className="text-2xl font-semibold mb-1">Parker DeLuca</h3>
              <p className="text-primary text-sm font-medium mb-6">Founder, CurlLoom</p>
              
              <p className="text-muted-foreground leading-relaxed max-w-xl mb-6">
                Community-focused, performance-driven brand builder. Parker founded CurlLoom to bring discipline and transparency to curl care, creating products that work through thoughtful formulation rather than marketing hype.
              </p>
              <p className="text-muted-foreground leading-relaxed max-w-xl">
                The goal is simple: build products that earn trust through performance, not promises. Everything else follows from there.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-12 lg:py-20 bg-card/30">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-12 text-center">
              What We Stand For
            </h2>
            
            <div className="grid sm:grid-cols-2 gap-6">
              {values.map((item, index) => (
                <div key={index} className="bg-card border border-border/60 rounded-xl p-6">
                  <h3 className="text-lg font-semibold mb-3">{item.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-xl mx-auto text-center">
            <h2 className="text-2xl font-bold tracking-tight mb-4">
              Explore Our Products
            </h2>
            <p className="text-muted-foreground mb-8">
              See how our approach translates into performance-focused curl care.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/shop">
                <Button className="bg-primary hover:bg-primary/90">
                  Shop Now
                </Button>
              </Link>
              <Link href="/ingredients">
                <Button variant="outline" className="border-border hover:bg-secondary">
                  Learn About Ingredients
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
