'use client'

import { useState } from 'react'
import { ChevronDown } from 'lucide-react'

const sections = [
  {
    id: 'acceptance',
    title: '1. Acceptance of Terms',
    content: `By accessing or using curlloom.co (the "Site"), purchasing products, or interacting with CurlLoom ("Company," "we," "us," or "our"), you agree to be bound by these Terms of Service ("Terms"). If you do not agree, do not use the Site.`,
  },
  {
    id: 'eligibility',
    title: '2. Eligibility',
    content: `You must be at least 18 years old to make purchases. By using this Site, you represent that you meet this requirement or are using the Site under supervision of a legal guardian.`,
  },
  {
    id: 'cosmetic',
    title: '3. Cosmetic Product Status',
    content: `CurlLoom products are cosmetic products intended for external use only. They are formulated and marketed in compliance with U.S. cosmetic law, including the Federal Food, Drug, and Cosmetic Act and the Modernization of Cosmetics Regulation Act of 2022.

CurlLoom products:
• Are not drugs
• Are not intended to diagnose, treat, cure, or prevent disease
• Do not alter the structure or function of the body

Individual results vary.`,
  },
  {
    id: 'orders',
    title: '4. Orders & Acceptance',
    content: `All orders are subject to availability and acceptance. CurlLoom reserves the right to:
• Refuse or cancel any order
• Limit quantities
• Correct pricing or system errors
• Discontinue products

Order confirmation does not constitute final acceptance if errors are discovered.`,
  },
  {
    id: 'pricing',
    title: '5. Pricing & Product Accuracy',
    content: `We attempt to ensure that descriptions, ingredient lists, and pricing are accurate. However:
• Typographical errors may occur
• Packaging may vary slightly
• Formulations may be updated

CurlLoom reserves the right to correct errors without prior notice.`,
  },
  {
    id: 'payment',
    title: '6. Payment',
    content: `Payments are processed securely via third-party payment providers. CurlLoom does not store full credit card numbers. You represent that you are authorized to use the submitted payment method.`,
  },
  {
    id: 'shipping-risk',
    title: '7. Shipping & Risk of Loss',
    content: `Title and risk of loss transfer to the customer upon delivery to the shipping carrier. CurlLoom is not responsible for:
• Carrier delays
• Lost packages after confirmed delivery
• Incorrect shipping information provided by the customer

If a package is marked "Delivered" by the carrier but not received, customers must contact the carrier directly.`,
  },
  {
    id: 'damaged-defective',
    title: '8. Damaged or Defective Products',
    content: `If a product arrives leaking, cracked, broken, with a damaged container, or materially defective, you must contact help@curlloom.co within 5 calendar days of delivery.

Include:
• Order number
• Photos of the damage
• Photos of packaging (including shipping box)
• Description of the issue

Failure to provide documentation within the stated timeframe may result in denial of replacement. If approved, CurlLoom may issue a replacement or refund at its discretion. Damage caused after delivery (e.g., dropping, improper storage, heat exposure) is not covered.`,
  },
  {
    id: 'returns',
    title: '9. Returns & Refunds',
    content: `All sales are final unless otherwise stated. If returns are permitted:
• Requests must be submitted within 14 calendar days of delivery
• Products must be unused and unopened
• Proof of purchase is required
• Shipping costs are non-refundable

Opened or used cosmetic products are not eligible for return due to hygiene and safety considerations. Excessive or abusive return behavior may result in account restriction.`,
  },
  {
    id: 'proper-use',
    title: '10. Proper Use & Assumption of Risk',
    content: `You agree to:
• Use products only as directed
• Perform patch testing
• Discontinue use if irritation occurs

All cosmetic products carry potential for individual sensitivity. CurlLoom is not liable for allergic reactions, known ingredient sensitivities, misuse, or improper storage.`,
  },
  {
    id: 'adverse',
    title: '11. Adverse Event Reporting',
    content: `If you experience a serious or unexpected reaction, including severe irritation, swelling, blistering, infection, or require medical treatment, discontinue use and seek medical attention.

Report adverse events to: help@curlloom.co

CurlLoom may document and retain adverse event information as required under the Modernization of Cosmetics Regulation Act of 2022. Submission does not constitute admission of liability.`,
  },
  {
    id: 'chargebacks',
    title: '12. Chargebacks & Payment Disputes',
    content: `Before initiating a chargeback, you agree to contact help@curlloom.co. If a chargeback is initiated without prior resolution attempt:
• CurlLoom may dispute it
• Fulfillment records may be submitted
• Future purchases may be restricted

Fraudulent chargebacks violate these Terms.`,
  },
  {
    id: 'wholesale',
    title: '13. Wholesale, Resale & MAP Policy',
    content: `Unauthorized resale, relabeling, or repackaging is prohibited. Retail partners may not:
• Make medical claims
• Alter packaging
• Sell on third-party marketplaces without written authorization

CurlLoom may establish a Minimum Advertised Price (MAP). Violations may result in termination of authorization.`,
  },
  {
    id: 'intellectual',
    title: '14. Intellectual Property',
    content: `All content on curlloom.co is the property of CurlLoom and may not be copied or reproduced without permission.`,
  },
  {
    id: 'user-submissions',
    title: '15. User Submissions',
    content: `Reviews, testimonials, or submitted content grant CurlLoom a non-exclusive, royalty-free license for marketing use.`,
  },
  {
    id: 'limitation',
    title: '16. Limitation of Liability',
    content: `To the maximum extent permitted by law, CurlLoom shall not be liable for indirect damages, incidental damages, consequential damages, lost profits, or emotional distress. Total liability shall not exceed the amount paid for the product in dispute.`,
  },
  {
    id: 'class-action',
    title: '17. Class Action Waiver',
    content: `All disputes must be brought individually. You waive the right to participate in class actions, representative actions, or consolidated proceedings.`,
  },
  {
    id: 'dispute-resolution',
    title: '18. Dispute Resolution & Arbitration',
    content: `Disputes shall first be addressed through good-faith negotiation. If unresolved, disputes shall be resolved through binding arbitration in the Commonwealth of Virginia. Each party bears its own legal costs unless otherwise required by law.`,
  },
  {
    id: 'force-majeure',
    title: '19. Force Majeure',
    content: `CurlLoom is not liable for failure to perform due to events beyond reasonable control, including natural disasters, supply chain disruptions, government actions, or carrier interruptions.`,
  },
  {
    id: 'severability',
    title: '20. Severability',
    content: `If any provision of these Terms is deemed unenforceable, the remaining provisions remain in effect.`,
  },
  {
    id: 'entire-agreement',
    title: '21. Entire Agreement',
    content: `These Terms constitute the entire agreement between you and CurlLoom regarding use of the Site and purchase of products.`,
  },
  {
    id: 'modifications',
    title: '22. Modifications',
    content: `CurlLoom may update these Terms at any time. Continued use of the Site constitutes acceptance of revisions.`,
  },
]

export default function TermsPage() {
  const [openSections, setOpenSections] = useState<string[]>([])

  const toggleSection = (id: string) => {
    setOpenSections(prev =>
      prev.includes(id)
        ? prev.filter(s => s !== id)
        : [...prev, id]
    )
  }

  return (
    <div className="flex flex-col">
      {/* Header */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-6">
              Terms of Service
            </h1>
            <p className="text-muted-foreground">
              Effective Date: February 2025 · Last Updated: February 2025
            </p>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-12 lg:py-20">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto space-y-3">
            {sections.map((section) => (
              <div
                key={section.id}
                className="border border-border/60 rounded-xl overflow-hidden"
              >
                <button
                  onClick={() => toggleSection(section.id)}
                  className="w-full flex items-center justify-between p-5 text-left hover:bg-card/50 transition-colors"
                >
                  <span className="font-medium pr-4">{section.title}</span>
                  <ChevronDown
                    className={`w-5 h-5 text-muted-foreground flex-shrink-0 transition-transform duration-200 ${
                      openSections.includes(section.id) ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {openSections.includes(section.id) && (
                  <div className="px-5 pb-5 text-muted-foreground whitespace-pre-line">
                    {section.content}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <section className="py-12 lg:py-16">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <p className="text-muted-foreground">
              Questions? Contact{' '}
              <a href="mailto:help@curlloom.co" className="text-primary hover:underline">
                help@curlloom.co
              </a>
            </p>
          </div>
        </div>
      </section>
    </div>
  )
}
