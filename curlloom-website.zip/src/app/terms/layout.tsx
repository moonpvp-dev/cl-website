import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Terms of Service | CurlLoom',
  description: 'Terms and conditions for using the CurlLoom website and purchasing our products.',
  openGraph: {
    title: 'Terms of Service | CurlLoom',
    description: 'Terms and conditions for using the CurlLoom website and purchasing our products.',
  },
}

export { default } from './page'
