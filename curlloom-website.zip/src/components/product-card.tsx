import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { EmailCapture } from './email-capture'

interface ProductCardProps {
  name: string
  subtitle?: string
  status: 'available' | 'tester' | 'coming-soon'
  bullets: string[]
  href: string
  variant?: 'default' | 'featured'
}

export function ProductCard({
  name,
  subtitle,
  status,
  bullets,
  href,
  variant = 'default',
}: ProductCardProps) {
  const getStatusBadge = () => {
    switch (status) {
      case 'available':
        return <Badge variant="default" className="bg-green-600 hover:bg-green-600/90">Available</Badge>
      case 'tester':
        return <Badge variant="default" className="bg-primary hover:bg-primary/90">Tester Access</Badge>
      case 'coming-soon':
        return <Badge variant="outline" className="border-muted-foreground/30 text-muted-foreground">Coming Soon</Badge>
    }
  }

  const getCTA = () => {
    switch (status) {
      case 'available':
        return (
          <Link href={href}>
            <Button variant="default" className="w-full bg-primary hover:bg-primary/90">
              Shop Now
            </Button>
          </Link>
        )
      case 'tester':
        return (
          <Link href="/testers">
            <Button variant="default" className="w-full bg-primary hover:bg-primary/90">
              Join Tester List
            </Button>
          </Link>
        )
      case 'coming-soon':
        return <EmailCapture variant="notify" productName={name} />
    }
  }

  return (
    <div 
      className={`group relative flex flex-col bg-card border border-border/60 rounded-xl overflow-hidden transition-all duration-300 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5 ${
        variant === 'featured' ? 'md:col-span-2 lg:col-span-1' : ''
      }`}
    >
      {/* Product Image Placeholder */}
      <div className="relative aspect-[4/5] bg-gradient-to-br from-secondary/50 to-secondary/30 overflow-hidden">
        <div className="absolute inset-0 spiral-bg opacity-50" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-32 h-40 rounded-lg bg-secondary/80 border border-border/40 flex items-center justify-center">
            <span className="text-xs text-muted-foreground text-center px-2">
              Product<br />Image
            </span>
          </div>
        </div>
        {/* Status Badge */}
        <div className="absolute top-4 right-4">
          {getStatusBadge()}
        </div>
      </div>

      {/* Content */}
      <div className="flex flex-col flex-1 p-6">
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-foreground mb-1">{name}</h3>
          {subtitle && (
            <p className="text-sm text-muted-foreground mb-4">{subtitle}</p>
          )}
          
          {/* Performance Bullets */}
          <ul className="space-y-2 mb-6">
            {bullets.map((bullet, index) => (
              <li key={index} className="flex items-start gap-2 text-sm text-muted-foreground">
                <svg className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>{bullet}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* CTA */}
        {getCTA()}
      </div>
    </div>
  )
}
