'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

interface EmailCaptureProps {
  variant?: 'tester' | 'notify' | 'newsletter'
  productName?: string
  className?: string
}

export function EmailCapture({ variant = 'newsletter', productName, className = '' }: EmailCaptureProps) {
  const [email, setEmail] = useState('')
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')

  const getCopy = () => {
    switch (variant) {
      case 'tester':
        return {
          placeholder: 'Enter your email',
          buttonText: 'Join Tester List',
          successMessage: 'You\'re on the list! We\'ll be in touch soon.',
          microcopy: 'No spam. Early access only.',
        }
      case 'notify':
        return {
          placeholder: 'Enter your email',
          buttonText: 'Notify Me',
          successMessage: 'We\'ll let you know when it\'s available.',
          microcopy: 'No spam. Product updates only.',
        }
      default:
        return {
          placeholder: 'Enter your email',
          buttonText: 'Subscribe',
          successMessage: 'Thanks for subscribing!',
          microcopy: 'No spam. Updates only.',
        }
    }
  }

  const copy = getCopy()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email) return

    setStatus('loading')
    
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))
    
    setStatus('success')
    setEmail('')
  }

  if (status === 'success') {
    return (
      <div className={`flex flex-col items-center gap-2 ${className}`}>
        <div className="flex items-center gap-2 text-primary">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
          <span className="text-sm">{copy.successMessage}</span>
        </div>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className={`flex flex-col sm:flex-row gap-3 ${className}`}>
      <Input
        type="email"
        placeholder={copy.placeholder}
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
        className="flex-1 bg-secondary/50 border-border focus:border-primary focus:ring-primary/20"
      />
      <Button 
        type="submit" 
        disabled={status === 'loading'}
        className="bg-primary hover:bg-primary/90 text-primary-foreground whitespace-nowrap"
      >
        {status === 'loading' ? 'Joining...' : copy.buttonText}
      </Button>
      <p className="text-xs text-muted-foreground sm:hidden">{copy.microcopy}</p>
    </form>
  )
}
